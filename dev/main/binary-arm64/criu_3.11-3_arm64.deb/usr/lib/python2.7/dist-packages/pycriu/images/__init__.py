import sys, os
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
from .magic import *
from .images import *
from .pb import *
