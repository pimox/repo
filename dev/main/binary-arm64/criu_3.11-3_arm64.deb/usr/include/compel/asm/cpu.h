#ifndef UAPI_COMPEL_ASM_CPU_H__
#define UAPI_COMPEL_ASM_CPU_H__

typedef struct { } compel_cpuinfo_t;

#endif /* UAPI_COMPEL_ASM_CPU_H__ */
