# 0.2.3 (January 7, 2019)

### Fixed
- Revert breaking change.

# 0.2.2 (January 7, 2019)

### Added
- General refactoring and inclusion of additional runtime options (#2022 and #2038)

# 0.2.1 (December 18, 2019)

### Fixes
- inherit visibility when wrapping async fn (#1954).

# 0.2.0 (November 26, 2019)

- Initial release
