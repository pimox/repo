Changes to this crate are tracked via [GitHub Releases][releases].

[releases]: https://github.com/sebasmagri/env_logger/releases
