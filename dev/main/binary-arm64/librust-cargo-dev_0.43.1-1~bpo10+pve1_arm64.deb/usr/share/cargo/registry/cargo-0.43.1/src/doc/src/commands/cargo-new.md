# cargo new
{{#include command-common.html}}
{{#include ../../man/generated/cargo-new.html}}
