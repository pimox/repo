# cargo vendor
{{#include command-common.html}}
{{#include ../../man/generated/cargo-vendor.html}}

