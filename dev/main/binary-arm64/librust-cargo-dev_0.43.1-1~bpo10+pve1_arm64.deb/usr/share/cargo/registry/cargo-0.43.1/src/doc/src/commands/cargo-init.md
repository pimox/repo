# cargo init
{{#include command-common.html}}
{{#include ../../man/generated/cargo-init.html}}
