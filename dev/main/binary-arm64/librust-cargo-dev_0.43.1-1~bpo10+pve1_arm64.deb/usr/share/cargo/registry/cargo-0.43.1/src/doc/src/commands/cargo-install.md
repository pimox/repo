# cargo install
{{#include command-common.html}}
{{#include ../../man/generated/cargo-install.html}}
