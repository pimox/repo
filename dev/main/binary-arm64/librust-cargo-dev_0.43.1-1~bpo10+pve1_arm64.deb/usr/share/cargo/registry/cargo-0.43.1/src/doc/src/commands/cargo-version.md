# cargo version
{{#include command-common.html}}
{{#include ../../man/generated/cargo-version.html}}
