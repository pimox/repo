# cargo test
{{#include command-common.html}}
{{#include ../../man/generated/cargo-test.html}}
