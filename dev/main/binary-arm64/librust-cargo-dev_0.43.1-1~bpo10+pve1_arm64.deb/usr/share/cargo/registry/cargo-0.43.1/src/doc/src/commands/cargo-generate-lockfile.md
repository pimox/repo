# cargo generate-lockfile
{{#include command-common.html}}
{{#include ../../man/generated/cargo-generate-lockfile.html}}
