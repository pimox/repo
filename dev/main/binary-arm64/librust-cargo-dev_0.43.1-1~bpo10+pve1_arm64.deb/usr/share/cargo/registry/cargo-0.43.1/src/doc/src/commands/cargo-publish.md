# cargo publish
{{#include command-common.html}}
{{#include ../../man/generated/cargo-publish.html}}
