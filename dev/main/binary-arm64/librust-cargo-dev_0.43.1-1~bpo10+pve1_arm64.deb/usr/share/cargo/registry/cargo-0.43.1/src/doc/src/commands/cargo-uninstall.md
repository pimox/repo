# cargo uninstall
{{#include command-common.html}}
{{#include ../../man/generated/cargo-uninstall.html}}
