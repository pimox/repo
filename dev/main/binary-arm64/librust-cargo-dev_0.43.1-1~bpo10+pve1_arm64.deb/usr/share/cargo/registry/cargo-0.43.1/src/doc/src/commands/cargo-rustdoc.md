# cargo rustdoc
{{#include command-common.html}}
{{#include ../../man/generated/cargo-rustdoc.html}}
