# cargo bench
{{#include command-common.html}}
{{#include ../../man/generated/cargo-bench.html}}
