//! Deprecated.
#[deprecated(note = "use cert_context::PrivateKey", since = "0.1.5")]
pub use crate::cert_context::PrivateKey as KeyHandle;
