"Hello! You want: cargo test --release --all-features"
