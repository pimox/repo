#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#define VERSION 1

void root(void);

#endif /* INCLUDE_GUARD_H */
