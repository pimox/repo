#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Bar Bar;

typedef struct Foo {

} Foo;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern const Bar BAR;

extern Foo FOO;

extern const int32_t NUMBER;

void root(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
