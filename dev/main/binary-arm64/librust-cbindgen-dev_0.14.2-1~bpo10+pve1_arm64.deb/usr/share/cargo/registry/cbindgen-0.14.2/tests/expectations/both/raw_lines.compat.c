#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#define VERSION 1

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void root(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* INCLUDE_GUARD_H */
