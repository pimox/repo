#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>

extern "C" {

extern const char CONST_GLOBAL_ARRAY[128];

extern char MUT_GLOBAL_ARRAY[128];

} // extern "C"
