#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>
#define VERSION 1

extern "C" {

void root();

} // extern "C"

#endif // INCLUDE_GUARD_H
