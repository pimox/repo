#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Option_i32 Option_i32;

typedef struct Result_i32__String Result_i32__String;

typedef struct Vec_String Vec_String;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void root(const Vec_String *a, const Option_i32 *b, const Result_i32__String *c);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
