#pragma once

#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>

extern "C" {

void root();

} // extern "C"
