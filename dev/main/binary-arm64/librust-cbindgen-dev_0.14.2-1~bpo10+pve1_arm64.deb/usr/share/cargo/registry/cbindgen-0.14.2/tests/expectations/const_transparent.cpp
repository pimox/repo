#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>

using Transparent = uint8_t;

static const Transparent FOO = 0;
