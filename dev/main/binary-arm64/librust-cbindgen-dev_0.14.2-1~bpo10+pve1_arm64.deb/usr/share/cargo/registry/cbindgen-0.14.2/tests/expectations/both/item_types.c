#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

enum OnlyThisShouldBeGenerated {
  Foo,
  Bar,
};
typedef uint8_t OnlyThisShouldBeGenerated;
