
extern "C" {

void root();

} // extern "C"
