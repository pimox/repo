#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Bar Bar;

typedef struct Foo {

} Foo;

extern const Bar BAR;

extern Foo FOO;

extern const int32_t NUMBER;

void root(void);
