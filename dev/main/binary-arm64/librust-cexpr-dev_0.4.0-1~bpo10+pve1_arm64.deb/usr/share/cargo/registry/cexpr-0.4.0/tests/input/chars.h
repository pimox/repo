#define CharChar_65 'A'
#define CharChar_127849 '\U0001f369' // 🍩
#define CharRaw_255 U'\xff'
