#define FAIL_function_like(x) 3
#define FAIL_empty
#define FAIL_invalid_for_radix 0b2
#define FAIL_shift_by_float 3<<1f
#define FAIL_unknown_identifier UNKNOWN
#define Int_0 0
#define Str_str "str"
#define FAIL_concat_integer "test" Str_str Int_0
#define FAIL_too_large_int 18446744073709551616
