#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

int32_t va_list_test(va_list ap);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
