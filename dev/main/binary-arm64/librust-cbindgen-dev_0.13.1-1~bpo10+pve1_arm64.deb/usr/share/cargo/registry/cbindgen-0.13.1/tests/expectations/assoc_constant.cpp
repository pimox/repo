#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>

struct Foo {

};
static const int32_t Foo_GA = 10;
static const float Foo_ZO = 3.14;

extern "C" {

void root(Foo x);

} // extern "C"
