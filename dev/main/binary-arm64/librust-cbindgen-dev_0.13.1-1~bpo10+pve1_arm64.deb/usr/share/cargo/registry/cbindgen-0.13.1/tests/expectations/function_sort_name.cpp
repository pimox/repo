#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <new>

extern "C" {

void A();

void B();

void C();

void D();

} // extern "C"
