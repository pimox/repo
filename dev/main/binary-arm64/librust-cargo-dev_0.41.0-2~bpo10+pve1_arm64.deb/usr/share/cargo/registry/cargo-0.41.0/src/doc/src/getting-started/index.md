## Getting Started

To get started with Cargo, install Cargo (and Rust) and set up your first crate.

* [Installation](installation.md)
* [First steps with Cargo](first-steps.md)
