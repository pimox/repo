# cargo package
{{#include command-common.html}}
{{#include ../../man/generated/cargo-package.html}}
