# cargo pkgid
{{#include command-common.html}}
{{#include ../../man/generated/cargo-pkgid.html}}
