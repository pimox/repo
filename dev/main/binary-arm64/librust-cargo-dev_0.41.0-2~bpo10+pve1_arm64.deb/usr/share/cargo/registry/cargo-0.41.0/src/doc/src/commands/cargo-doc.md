# cargo doc
{{#include command-common.html}}
{{#include ../../man/generated/cargo-doc.html}}
