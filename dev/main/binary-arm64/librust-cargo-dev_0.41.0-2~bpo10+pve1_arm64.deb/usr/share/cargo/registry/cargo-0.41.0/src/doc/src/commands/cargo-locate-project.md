# cargo locate-project
{{#include command-common.html}}
{{#include ../../man/generated/cargo-locate-project.html}}
