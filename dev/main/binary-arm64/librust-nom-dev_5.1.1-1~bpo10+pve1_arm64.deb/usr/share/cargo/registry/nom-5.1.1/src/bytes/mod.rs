//! parsers recognizing bytes streams

#[macro_use]
mod macros;
pub mod streaming;
pub mod complete;

