package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '6.4-4rpve1';
}

sub release {
    return '6.4';
}

sub repoid {
    return 'd9210bff';
}

sub version_text {
    return '6.4-4rpve1/d9210bff';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '6.4-4rpve1',
	'release' => '6.4',
	'repoid' => 'd9210bff',
    }
}

1;
