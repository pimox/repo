# Contributing

This is the first procedural macro crate I've ever written, and I presume it
shows.

Pretty much any contribution is welcome, be it an implementation, design idea,
project information, or anything else I can't imagine at the moment. You can
reach me here, Twitter, Reddit, and possibly the Rust IRC, all under this name.

Thanks!
