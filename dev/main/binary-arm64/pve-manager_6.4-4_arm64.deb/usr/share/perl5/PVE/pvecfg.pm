package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '6.4-4';
}

sub release {
    return '6.4';
}

sub repoid {
    return '337d6701';
}

sub version_text {
    return '6.4-4/337d6701';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '6.4-4',
	'release' => '6.4',
	'repoid' => '337d6701',
    }
}

1;
