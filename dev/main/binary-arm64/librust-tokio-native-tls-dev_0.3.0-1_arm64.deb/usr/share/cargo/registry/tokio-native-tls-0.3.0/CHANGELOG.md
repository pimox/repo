# 0.3.0 (December 23, 2020)

- Upgrade to `tokio 1.0`.

# 0.2.0 (October 16, 2020)

- Upgrade to `tokio 0.3`.

# 0.1.0 (January 9th, 2019)

- Initial release from `tokio-tls 0.3`
