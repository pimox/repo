#![feature(test)]

extern crate test;

mod basic;
mod vec_map;
