use proc_macro_hack::proc_macro_hack;

#[proc_macro_hack]
pub struct What;

fn main() {}
