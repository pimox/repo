# cargo rustc
{{#include command-common.html}}
{{#include ../../man/generated/cargo-rustc.html}}
