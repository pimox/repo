# cargo fix
{{#include command-common.html}}
{{#include ../../man/generated/cargo-fix.html}}
