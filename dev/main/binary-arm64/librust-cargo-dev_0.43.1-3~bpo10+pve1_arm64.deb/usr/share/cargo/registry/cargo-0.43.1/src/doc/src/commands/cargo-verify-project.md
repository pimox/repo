# cargo verify-project
{{#include command-common.html}}
{{#include ../../man/generated/cargo-verify-project.html}}
