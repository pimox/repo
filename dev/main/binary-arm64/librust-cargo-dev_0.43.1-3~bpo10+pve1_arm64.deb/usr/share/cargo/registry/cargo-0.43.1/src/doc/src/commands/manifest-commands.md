# Manifest Commands
* [cargo generate-lockfile](cargo-generate-lockfile.md)
* [cargo locate-project](cargo-locate-project.md)
* [cargo metadata](cargo-metadata.md)
* [cargo pkgid](cargo-pkgid.md)
* [cargo update](cargo-update.md)
* [cargo vendor](cargo-vendor.md)
* [cargo verify-project](cargo-verify-project.md)
