# cargo search
{{#include command-common.html}}
{{#include ../../man/generated/cargo-search.html}}
