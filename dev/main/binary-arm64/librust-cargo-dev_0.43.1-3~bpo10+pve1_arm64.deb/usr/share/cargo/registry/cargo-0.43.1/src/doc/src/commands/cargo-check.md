# cargo check
{{#include command-common.html}}
{{#include ../../man/generated/cargo-check.html}}
