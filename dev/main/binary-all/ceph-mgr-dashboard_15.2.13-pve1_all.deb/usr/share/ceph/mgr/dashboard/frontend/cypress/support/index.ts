import './commands';

afterEach(() => {
  cy.visit('#/403');
});
