export enum RbdFormMode {
  editing = 'editing',
  cloning = 'cloning',
  copying = 'copying'
}
