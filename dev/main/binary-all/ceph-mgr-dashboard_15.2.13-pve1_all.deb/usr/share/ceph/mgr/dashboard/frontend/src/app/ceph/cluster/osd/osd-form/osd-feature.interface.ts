export interface OsdFeature {
  desc: string;
  key?: string;
}
