import { InventoryDevice } from './inventory-devices/inventory-device.model';

export class InventoryHost {
  name: string;
  devices: InventoryDevice[];
}
