export enum RgwBucketVersioning {
  ENABLED = 'Enabled',
  SUSPENDED = 'Suspended'
}
