export enum NFSClusterType {
  user = 'user',
  orchestrator = 'orchestrator'
}
