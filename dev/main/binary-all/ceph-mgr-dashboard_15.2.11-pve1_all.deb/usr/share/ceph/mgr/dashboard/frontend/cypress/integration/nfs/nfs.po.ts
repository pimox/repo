import { PageHelper } from '../page-helper.po';

export class NfsPageHelper extends PageHelper {
  pages = { index: { url: '#/nfs', id: 'cd-nfs-501' } };
}
