export class RbdParentModel {
  image_name: string;
  pool_name: string;
  pool_namespace: string;
  snap_name: string;
}
