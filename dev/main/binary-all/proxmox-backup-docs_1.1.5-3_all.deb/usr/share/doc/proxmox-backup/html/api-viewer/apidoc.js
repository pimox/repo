var pbsapi = [
  {
    "children": [
      {
        "children": [
          {
            "info": {
              "GET": {
                "description": "Read Access Control List (ACLs).",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Read Access Control List (ACLs).",
                  "properties": {
                    "exact": {
                      "default": false,
                      "description": "If set, returns only ACL for the exact path.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "path": {
                      "description": "Access control path.",
                      "maxLength": 128,
                      "minLength": 1,
                      "optional": 1,
                      "pattern": "/^(?:/|(?:/(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))+)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Returns all ACLs if user has Sys.Audit on '/access/acl', or just the ACLs containing the user's API tokens.",
                  "user": "all"
                },
                "returns": {
                  "description": "ACL entry list.",
                  "items": {
                    "additionalProperties": false,
                    "description": "ACL list entry.",
                    "properties": {
                      "path": {
                        "description": "Access control path.",
                        "maxLength": 128,
                        "minLength": 1,
                        "pattern": "/^(?:/|(?:/(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))+)$/",
                        "type": "string"
                      },
                      "propagate": {
                        "default": true,
                        "description": "Allow to propagate (inherit) permissions.",
                        "type": "boolean"
                      },
                      "roleid": {
                        "description": "Enum representing roles via their [PRIVILEGES] combination.\n\nSince privileges are implemented as bitflags, each unique combination of privileges maps to a\nsingle, unique `u64` value that is used in this enum definition.",
                        "enum": [
                          "Admin",
                          "Audit",
                          "NoAccess",
                          "DatastoreAdmin",
                          "DatastoreReader",
                          "DatastoreBackup",
                          "DatastorePowerUser",
                          "DatastoreAudit",
                          "RemoteAudit",
                          "RemoteAdmin",
                          "RemoteSyncOperator",
                          "TapeAudit",
                          "TapeAdmin",
                          "TapeOperator",
                          "TapeReader"
                        ],
                        "type": "string",
                        "typetext": "<role>"
                      },
                      "ugid": {
                        "description": "User or Group ID.",
                        "type": "string"
                      },
                      "ugid_type": {
                        "description": "Type of 'ugid' property.",
                        "enum": [
                          "user",
                          "group"
                        ],
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "PUT": {
                "description": "Update Access Control List (ACLs).",
                "method": "PUT",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Update Access Control List (ACLs).",
                  "properties": {
                    "auth-id": {
                      "description": "Authentication ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                      "type": "string"
                    },
                    "delete": {
                      "description": "Remove permissions (instead of adding it).",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "digest": {
                      "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                      "optional": 1,
                      "pattern": "/^[a-f0-9]{64}$/",
                      "type": "string"
                    },
                    "group": {
                      "description": "Group ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "Access control path.",
                      "maxLength": 128,
                      "minLength": 1,
                      "pattern": "/^(?:/|(?:/(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))+)$/",
                      "type": "string"
                    },
                    "propagate": {
                      "default": true,
                      "description": "Allow to propagate (inherit) permissions.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "role": {
                      "description": "Enum representing roles via their [PRIVILEGES] combination.\n\nSince privileges are implemented as bitflags, each unique combination of privileges maps to a\nsingle, unique `u64` value that is used in this enum definition.",
                      "enum": [
                        "Admin",
                        "Audit",
                        "NoAccess",
                        "DatastoreAdmin",
                        "DatastoreReader",
                        "DatastoreBackup",
                        "DatastorePowerUser",
                        "DatastoreAudit",
                        "RemoteAudit",
                        "RemoteAdmin",
                        "RemoteSyncOperator",
                        "TapeAudit",
                        "TapeAdmin",
                        "TapeOperator",
                        "TapeReader"
                      ],
                      "type": "string",
                      "typetext": "<role>"
                    }
                  }
                },
                "permissions": {
                  "description": "Requires Permissions.Modify on '/access/acl', limited to updating ACLs of the user's API tokens otherwise.",
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 1,
            "path": "/access/acl",
            "text": "acl"
          },
          {
            "info": {
              "GET": {
                "description": "Authentication domain/realm index.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Authentication domain/realm index.",
                  "properties": {}
                },
                "permissions": {
                  "description": "Anyone can access this, because we need that list for the login box (before the user is authenticated).",
                  "user": "world"
                },
                "returns": {
                  "description": "List of realms.",
                  "items": {
                    "additionalProperties": false,
                    "description": "User configuration (without password).",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "default": {
                        "description": "Default realm.",
                        "type": "boolean"
                      },
                      "realm": {
                        "description": "Realm ID.",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 1,
            "path": "/access/domains",
            "text": "domains"
          },
          {
            "info": {
              "PUT": {
                "description": "Change user password\n\nEach user is allowed to change his own password. Superuser\ncan change all passwords.",
                "method": "PUT",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Change user password\n\nEach user is allowed to change his own password. Superuser\ncan change all passwords.",
                  "properties": {
                    "password": {
                      "description": "Password.",
                      "maxLength": 1024,
                      "minLength": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "userid": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Everybody is allowed to change their own password. In addition, users with 'Permissions:Modify' privilege may change any password on @pbs realm.",
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 1,
            "path": "/access/password",
            "text": "password"
          },
          {
            "info": {
              "GET": {
                "description": "List permissions of given or currently authenticated user / API token.\n\nOptionally limited to specific path.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List permissions of given or currently authenticated user / API token.\n\nOptionally limited to specific path.",
                  "properties": {
                    "auth-id": {
                      "description": "Authentication ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "Access control path.",
                      "maxLength": 128,
                      "minLength": 1,
                      "optional": 1,
                      "pattern": "/^(?:/|(?:/(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))+)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Requires Sys.Audit on '/access', limited to own privileges otherwise.",
                  "user": "all"
                },
                "returns": {
                  "additionalProperties": true,
                  "description": "Map of ACL path to Map of privilege to propagate bit",
                  "properties": {},
                  "type": "object"
                }
              }
            },
            "leaf": 1,
            "path": "/access/permissions",
            "text": "permissions"
          },
          {
            "info": {
              "GET": {
                "description": "Role list",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Role list",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "description": "List of roles.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Role with description and privileges.",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "privs": {
                        "description": "List of Privileges",
                        "items": {
                          "description": "A Privilege",
                          "type": "string"
                        },
                        "type": "array"
                      },
                      "roleid": {
                        "description": "Enum representing roles via their [PRIVILEGES] combination.\n\nSince privileges are implemented as bitflags, each unique combination of privileges maps to a\nsingle, unique `u64` value that is used in this enum definition.",
                        "enum": [
                          "Admin",
                          "Audit",
                          "NoAccess",
                          "DatastoreAdmin",
                          "DatastoreReader",
                          "DatastoreBackup",
                          "DatastorePowerUser",
                          "DatastoreAudit",
                          "RemoteAudit",
                          "RemoteAdmin",
                          "RemoteSyncOperator",
                          "TapeAudit",
                          "TapeAdmin",
                          "TapeOperator",
                          "TapeReader"
                        ],
                        "type": "string",
                        "typetext": "<role>"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 1,
            "path": "/access/roles",
            "text": "roles"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "DELETE": {
                        "description": "Delete a single TFA entry.",
                        "method": "DELETE",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Delete a single TFA entry.",
                          "properties": {
                            "id": {
                              "description": "the tfa entry id",
                              "type": "string"
                            },
                            "password": {
                              "description": "Password.",
                              "maxLength": 1024,
                              "minLength": 1,
                              "optional": 1,
                              "pattern": "/^[[:^cntrl:]]*$/",
                              "type": "string"
                            },
                            "userid": {
                              "description": "User ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "or": [
                            {
                              "check": {
                                "partial": false,
                                "path": [
                                  "access",
                                  "users"
                                ],
                                "privs": [
                                  "Permissions.Modify"
                                ]
                              }
                            },
                            {
                              "userParam": "userid"
                            }
                          ]
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "GET": {
                        "description": "Get a single TFA entry.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get a single TFA entry.",
                          "properties": {
                            "id": {
                              "description": "the tfa entry id",
                              "type": "string"
                            },
                            "userid": {
                              "description": "User ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "or": [
                            {
                              "check": {
                                "partial": false,
                                "path": [
                                  "access",
                                  "users"
                                ],
                                "privs": [
                                  "Permissions.Modify"
                                ]
                              }
                            },
                            {
                              "userParam": "userid"
                            }
                          ]
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "PUT": {
                        "description": "Update user's TFA entry description.",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Update user's TFA entry description.",
                          "properties": {
                            "description": {
                              "description": "A description to distinguish multiple entries from one another",
                              "maxLength": 255,
                              "optional": 1,
                              "type": "string"
                            },
                            "enable": {
                              "description": "Whether this entry should currently be enabled or disabled",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "id": {
                              "description": "the tfa entry id",
                              "type": "string"
                            },
                            "password": {
                              "description": "Password.",
                              "maxLength": 1024,
                              "minLength": 1,
                              "optional": 1,
                              "pattern": "/^[[:^cntrl:]]*$/",
                              "type": "string"
                            },
                            "userid": {
                              "description": "User ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "or": [
                            {
                              "check": {
                                "partial": false,
                                "path": [
                                  "access",
                                  "users"
                                ],
                                "privs": [
                                  "Permissions.Modify"
                                ]
                              }
                            },
                            {
                              "userParam": "userid"
                            }
                          ]
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/access/tfa/{userid}/{id}",
                    "text": "{id}"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Add a TOTP secret to the user.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Add a TOTP secret to the user.",
                      "properties": {
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "or": [
                        {
                          "check": {
                            "partial": false,
                            "path": [
                              "access",
                              "users"
                            ],
                            "privs": [
                              "Permissions.Modify"
                            ]
                          }
                        },
                        {
                          "userParam": "userid"
                        }
                      ]
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "POST": {
                    "description": "Add a TFA entry to the user.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Add a TFA entry to the user.",
                      "properties": {
                        "challenge": {
                          "description": "When responding to a u2f challenge: the original challenge string",
                          "optional": 1,
                          "type": "string"
                        },
                        "description": {
                          "description": "A description to distinguish multiple entries from one another",
                          "maxLength": 255,
                          "optional": 1,
                          "type": "string"
                        },
                        "password": {
                          "description": "Password.",
                          "maxLength": 1024,
                          "minLength": 1,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "totp": {
                          "description": "A totp URI.",
                          "optional": 1,
                          "type": "string"
                        },
                        "type": {
                          "description": "A TFA entry type.",
                          "enum": [
                            "totp",
                            "u2f",
                            "webauthn",
                            "recovery"
                          ],
                          "type": "string"
                        },
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "value": {
                          "description": "The current value for the provided totp URI, or a Webauthn/U2F challenge response",
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "or": [
                        {
                          "check": {
                            "partial": false,
                            "path": [
                              "access",
                              "users"
                            ],
                            "privs": [
                              "Permissions.Modify"
                            ]
                          }
                        },
                        {
                          "userParam": "userid"
                        }
                      ]
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "The result returned when adding TFA entries to a user.",
                      "properties": {
                        "challenge": {
                          "description": "When adding u2f entries, this contains a challenge the user must respond to in order to\nfinish the registration.",
                          "optional": 1,
                          "type": "string"
                        },
                        "id": {
                          "description": "The id if a newly added TFA entry.",
                          "optional": 1,
                          "type": "string"
                        },
                        "recovery": {
                          "description": "A list of recovery codes as integers.",
                          "items": {
                            "description": "A one-time usable recovery code entry.",
                            "type": "integer"
                          },
                          "type": "array"
                        }
                      },
                      "type": "object"
                    }
                  }
                },
                "leaf": 0,
                "path": "/access/tfa/{userid}",
                "text": "{userid}"
              }
            ],
            "info": {
              "GET": {
                "description": "List user TFA configuration.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List user TFA configuration.",
                  "properties": {}
                },
                "permissions": {
                  "description": "Returns all or just the logged-in user, depending on privileges.",
                  "user": "all"
                },
                "returns": {
                  "description": "The list tuples of user and TFA entries.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Over the API we only provide the descriptions for TFA data.",
                    "properties": {
                      "entries": {
                        "description": "TFA entries.",
                        "items": {
                          "additionalProperties": true,
                          "description": "A TFA entry for a user.",
                          "properties": {
                            "created": {
                              "description": "Creation time of this entry as unix epoch.",
                              "type": "integer"
                            },
                            "description": {
                              "description": "User chosen description for this entry.",
                              "type": "string"
                            },
                            "enable": {
                              "description": "Whether this TFA entry is currently enabled.",
                              "type": "boolean"
                            },
                            "id": {
                              "description": "The id used to reference this entry.",
                              "type": "string"
                            },
                            "type": {
                              "description": "A TFA entry type.",
                              "enum": [
                                "totp",
                                "u2f",
                                "webauthn",
                                "recovery"
                              ],
                              "type": "string"
                            }
                          },
                          "type": "object"
                        },
                        "type": "array"
                      },
                      "userid": {
                        "description": "User ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/access/tfa",
            "text": "tfa"
          },
          {
            "info": {
              "POST": {
                "description": "Create or verify authentication ticket.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create or verify authentication ticket.",
                  "properties": {
                    "password": {
                      "description": "Password.",
                      "maxLength": 1024,
                      "minLength": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "Path for verifying terminal tickets.",
                      "optional": 1,
                      "type": "string"
                    },
                    "port": {
                      "description": "Port for verifying terminal tickets.",
                      "optional": 1,
                      "type": "integer"
                    },
                    "privs": {
                      "description": "Privilege for verifying terminal tickets.",
                      "optional": 1,
                      "type": "string"
                    },
                    "tfa-challenge": {
                      "description": "The signed TFA challenge string the user wants to respond to.",
                      "optional": 1,
                      "type": "string"
                    },
                    "username": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "user": "world"
                },
                "returns": {
                  "additionalProperties": false,
                  "description": "An authentication ticket with additional infos.",
                  "properties": {
                    "CSRFPreventionToken": {
                      "description": "Cross Site Request Forgery Prevention Token. For partial tickets this is the string \"invalid\".",
                      "type": "string"
                    },
                    "ticket": {
                      "description": "Auth ticket.",
                      "type": "string"
                    },
                    "username": {
                      "description": "User name.",
                      "type": "string"
                    }
                  },
                  "type": "object"
                }
              }
            },
            "leaf": 1,
            "path": "/access/ticket",
            "text": "ticket"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "children": [
                      {
                        "info": {
                          "DELETE": {
                            "description": "Delete a user's API token",
                            "method": "DELETE",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Delete a user's API token",
                              "properties": {
                                "digest": {
                                  "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                                  "optional": 1,
                                  "pattern": "/^[a-f0-9]{64}$/",
                                  "type": "string"
                                },
                                "tokenname": {
                                  "description": "The token ID part of an API token authentication id.\n\nThis alone does NOT uniquely identify the API token - use a full `Authid` for such use cases.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "userid": {
                                  "description": "User ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "or": [
                                {
                                  "check": {
                                    "partial": false,
                                    "path": [
                                      "access",
                                      "users"
                                    ],
                                    "privs": [
                                      "Permissions.Modify"
                                    ]
                                  }
                                },
                                {
                                  "userParam": "userid"
                                }
                              ]
                            },
                            "returns": {
                              "type": "null"
                            }
                          },
                          "GET": {
                            "description": "Read user's API token metadata",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Read user's API token metadata",
                              "properties": {
                                "tokenname": {
                                  "description": "The token ID part of an API token authentication id.\n\nThis alone does NOT uniquely identify the API token - use a full `Authid` for such use cases.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "userid": {
                                  "description": "User ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "or": [
                                {
                                  "check": {
                                    "partial": false,
                                    "path": [
                                      "access",
                                      "users"
                                    ],
                                    "privs": [
                                      "Sys.Audit"
                                    ]
                                  }
                                },
                                {
                                  "userParam": "userid"
                                }
                              ]
                            },
                            "returns": {
                              "additionalProperties": false,
                              "description": "ApiToken properties.",
                              "properties": {
                                "comment": {
                                  "description": "Comment (single line).",
                                  "optional": 1,
                                  "pattern": "/^[[:^cntrl:]]*$/",
                                  "type": "string"
                                },
                                "enable": {
                                  "default": true,
                                  "description": "Enable the account (default). You can set this to '0' to disable the account.",
                                  "optional": 1,
                                  "type": "boolean"
                                },
                                "expire": {
                                  "default": 0,
                                  "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                                  "minimum": 0,
                                  "optional": 1,
                                  "type": "integer"
                                },
                                "tokenid": {
                                  "description": "API Token ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              },
                              "type": "object"
                            }
                          },
                          "POST": {
                            "description": "Generate a new API token with given metadata",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Generate a new API token with given metadata",
                              "properties": {
                                "comment": {
                                  "description": "Comment (single line).",
                                  "optional": 1,
                                  "pattern": "/^[[:^cntrl:]]*$/",
                                  "type": "string"
                                },
                                "digest": {
                                  "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                                  "optional": 1,
                                  "pattern": "/^[a-f0-9]{64}$/",
                                  "type": "string"
                                },
                                "enable": {
                                  "default": true,
                                  "description": "Enable the account (default). You can set this to '0' to disable the account.",
                                  "optional": 1,
                                  "type": "boolean"
                                },
                                "expire": {
                                  "default": 0,
                                  "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                                  "minimum": 0,
                                  "optional": 1,
                                  "type": "integer"
                                },
                                "tokenname": {
                                  "description": "The token ID part of an API token authentication id.\n\nThis alone does NOT uniquely identify the API token - use a full `Authid` for such use cases.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "userid": {
                                  "description": "User ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "or": [
                                {
                                  "check": {
                                    "partial": false,
                                    "path": [
                                      "access",
                                      "users"
                                    ],
                                    "privs": [
                                      "Permissions.Modify"
                                    ]
                                  }
                                },
                                {
                                  "userParam": "userid"
                                }
                              ]
                            },
                            "returns": {
                              "additionalProperties": false,
                              "description": "API token identifier + generated secret.",
                              "properties": {
                                "tokenid": {
                                  "description": "The API token identifier",
                                  "type": "string"
                                },
                                "value": {
                                  "description": "The API token secret",
                                  "type": "string"
                                }
                              },
                              "type": "object"
                            }
                          },
                          "PUT": {
                            "description": "Update user's API token metadata",
                            "method": "PUT",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Update user's API token metadata",
                              "properties": {
                                "comment": {
                                  "description": "Comment (single line).",
                                  "optional": 1,
                                  "pattern": "/^[[:^cntrl:]]*$/",
                                  "type": "string"
                                },
                                "digest": {
                                  "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                                  "optional": 1,
                                  "pattern": "/^[a-f0-9]{64}$/",
                                  "type": "string"
                                },
                                "enable": {
                                  "default": true,
                                  "description": "Enable the account (default). You can set this to '0' to disable the account.",
                                  "optional": 1,
                                  "type": "boolean"
                                },
                                "expire": {
                                  "default": 0,
                                  "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                                  "minimum": 0,
                                  "optional": 1,
                                  "type": "integer"
                                },
                                "tokenname": {
                                  "description": "The token ID part of an API token authentication id.\n\nThis alone does NOT uniquely identify the API token - use a full `Authid` for such use cases.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "userid": {
                                  "description": "User ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "or": [
                                {
                                  "check": {
                                    "partial": false,
                                    "path": [
                                      "access",
                                      "users"
                                    ],
                                    "privs": [
                                      "Permissions.Modify"
                                    ]
                                  }
                                },
                                {
                                  "userParam": "userid"
                                }
                              ]
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/access/users/{userid}/token/{tokenname}",
                        "text": "{tokenname}"
                      }
                    ],
                    "info": {
                      "GET": {
                        "description": "List user's API tokens",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List user's API tokens",
                          "properties": {
                            "userid": {
                              "description": "User ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "or": [
                            {
                              "check": {
                                "partial": false,
                                "path": [
                                  "access",
                                  "users"
                                ],
                                "privs": [
                                  "Sys.Audit"
                                ]
                              }
                            },
                            {
                              "userParam": "userid"
                            }
                          ]
                        },
                        "returns": {
                          "description": "List user's API tokens (with config digest).",
                          "items": {
                            "additionalProperties": false,
                            "description": "ApiToken properties.",
                            "properties": {
                              "comment": {
                                "description": "Comment (single line).",
                                "optional": 1,
                                "pattern": "/^[[:^cntrl:]]*$/",
                                "type": "string"
                              },
                              "enable": {
                                "default": true,
                                "description": "Enable the account (default). You can set this to '0' to disable the account.",
                                "optional": 1,
                                "type": "boolean"
                              },
                              "expire": {
                                "default": 0,
                                "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                                "minimum": 0,
                                "optional": 1,
                                "type": "integer"
                              },
                              "tokenid": {
                                "description": "API Token ID",
                                "maxLength": 64,
                                "minLength": 3,
                                "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/access/users/{userid}/token",
                    "text": "token"
                  }
                ],
                "info": {
                  "DELETE": {
                    "description": "Remove a user from the configuration file.",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a user from the configuration file.",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "or": [
                        {
                          "check": {
                            "partial": false,
                            "path": [
                              "access",
                              "users"
                            ],
                            "privs": [
                              "Permissions.Modify"
                            ]
                          }
                        },
                        {
                          "userParam": "userid"
                        }
                      ]
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read user configuration data.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read user configuration data.",
                      "properties": {
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "or": [
                        {
                          "check": {
                            "partial": false,
                            "path": [
                              "access",
                              "users"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        {
                          "userParam": "userid"
                        }
                      ]
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "User properties.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "email": {
                          "description": "E-Mail Address.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "enable": {
                          "default": true,
                          "description": "Enable the account (default). You can set this to '0' to disable the account.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "expire": {
                          "default": 0,
                          "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "firstname": {
                          "description": "First name.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "lastname": {
                          "description": "Last name.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update user configuration.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update user configuration.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "",
                            "enum": [
                              "comment",
                              "firstname",
                              "lastname",
                              "email"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "email": {
                          "description": "E-Mail Address.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "enable": {
                          "default": true,
                          "description": "Enable the account (default). You can set this to '0' to disable the account.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "expire": {
                          "default": 0,
                          "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "firstname": {
                          "description": "First name.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "lastname": {
                          "description": "Last name.",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "password": {
                          "description": "User Password.",
                          "maxLength": 64,
                          "minLength": 5,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "userid": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "or": [
                        {
                          "check": {
                            "partial": false,
                            "path": [
                              "access",
                              "users"
                            ],
                            "privs": [
                              "Permissions.Modify"
                            ]
                          }
                        },
                        {
                          "userParam": "userid"
                        }
                      ]
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/access/users/{userid}",
                "text": "{userid}"
              }
            ],
            "info": {
              "GET": {
                "description": "List users",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List users",
                  "properties": {
                    "include_tokens": {
                      "default": false,
                      "description": "Include user's API tokens in returned list.",
                      "optional": 1,
                      "type": "boolean"
                    }
                  }
                },
                "permissions": {
                  "description": "Returns all or just the logged-in user (/API token owner), depending on privileges.",
                  "user": "all"
                },
                "returns": {
                  "description": "List users (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "User properties with added list of ApiTokens",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "email": {
                        "description": "E-Mail Address.",
                        "maxLength": 64,
                        "minLength": 2,
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "enable": {
                        "default": true,
                        "description": "Enable the account (default). You can set this to '0' to disable the account.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "expire": {
                        "default": 0,
                        "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                        "minimum": 0,
                        "optional": 1,
                        "type": "integer"
                      },
                      "firstname": {
                        "description": "First name.",
                        "maxLength": 64,
                        "minLength": 2,
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "lastname": {
                        "description": "Last name.",
                        "maxLength": 64,
                        "minLength": 2,
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "tokens": {
                        "description": "List of user's API tokens.",
                        "items": {
                          "additionalProperties": false,
                          "description": "ApiToken properties.",
                          "properties": {
                            "comment": {
                              "description": "Comment (single line).",
                              "optional": 1,
                              "pattern": "/^[[:^cntrl:]]*$/",
                              "type": "string"
                            },
                            "enable": {
                              "default": true,
                              "description": "Enable the account (default). You can set this to '0' to disable the account.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "expire": {
                              "default": 0,
                              "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "tokenid": {
                              "description": "API Token ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          },
                          "type": "object"
                        },
                        "optional": 1,
                        "type": "array"
                      },
                      "userid": {
                        "description": "User ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create new user.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create new user.",
                  "properties": {
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "email": {
                      "description": "E-Mail Address.",
                      "maxLength": 64,
                      "minLength": 2,
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "enable": {
                      "default": true,
                      "description": "Enable the account (default). You can set this to '0' to disable the account.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "expire": {
                      "default": 0,
                      "description": "Account expiration date (seconds since epoch). '0' means no expiration date.",
                      "minimum": 0,
                      "optional": 1,
                      "type": "integer"
                    },
                    "firstname": {
                      "description": "First name.",
                      "maxLength": 64,
                      "minLength": 2,
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "lastname": {
                      "description": "Last name.",
                      "maxLength": 64,
                      "minLength": 2,
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "password": {
                      "description": "User Password.",
                      "maxLength": 64,
                      "minLength": 5,
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "userid": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "access",
                      "users"
                    ],
                    "privs": [
                      "Permissions.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/access/users",
            "text": "users"
          }
        ],
        "info": {
          "GET": {
            "description": "Directory index.",
            "method": "GET",
            "parameters": {
              "additionalProperties": true,
              "description": "Directory index.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 0,
        "path": "/access",
        "text": "access"
      },
      {
        "children": [
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "GET": {
                        "description": "Get the entries of the given path of the catalog",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get the entries of the given path of the catalog",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "filepath": {
                              "description": "Base64 encoded path.",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Read",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/catalog",
                    "text": "catalog"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Change owner of a backup group",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Change owner of a backup group",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "new-owner": {
                              "description": "Authentication ID",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "description": "Datastore.Modify on whole datastore, or changing ownership between user and a user's token for owned backups with Datastore.Backup",
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/change-owner",
                    "text": "change-owner"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Download single raw file from backup snapshot.",
                        "method": "DOWNLOAD",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Download single raw file from backup snapshot.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "file-name": {
                              "description": "Backup archive name.",
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Read",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/download",
                    "text": "download"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Download single decoded file from backup snapshot. Only works if it's not encrypted.",
                        "method": "DOWNLOAD",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Download single decoded file from backup snapshot. Only works if it's not encrypted.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "file-name": {
                              "description": "Backup archive name.",
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Read",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/download-decoded",
                    "text": "download-decoded"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "List snapshot files.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List snapshot files.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Read",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Returns the list of archive files inside a backup snapshots.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Basic information about archive files inside a backup snapshot.",
                            "properties": {
                              "crypt-mode": {
                                "default": "encrypt",
                                "description": "Defines whether data is encrypted (using an AEAD cipher), only signed, or neither.",
                                "enum": [
                                  "none",
                                  "encrypt",
                                  "sign-only"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "filename": {
                                "description": "Backup archive name.",
                                "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              },
                              "size": {
                                "description": "Archive size (from backup manifest).",
                                "minimum": 0,
                                "optional": 1,
                                "type": "integer"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/files",
                    "text": "files"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Garbage collection status.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Garbage collection status.",
                          "properties": {
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Garbage collection status.",
                          "properties": {
                            "disk-bytes": {
                              "description": "Bytes used on disk.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "disk-chunks": {
                              "description": "Chunks used on disk.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "index-data-bytes": {
                              "description": "Sum of bytes referred by index files.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "index-file-count": {
                              "description": "Number of processed index files.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "pending-bytes": {
                              "description": "Sum of pending bytes (pending removal - kept for safety).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "pending-chunks": {
                              "description": "Number of pending chunks (pending removal - kept for safety).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "removed-bad": {
                              "description": "Number of chunks marked as .bad by verify that have been removed by GC.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "removed-bytes": {
                              "description": "Sum of removed bytes.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "removed-chunks": {
                              "description": "Number of removed chunks.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "still-bad": {
                              "description": "Number of chunks still marked as .bad after garbage collection.",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "upid": {
                              "description": "Unique Process/Task ID.",
                              "maxLength": 256,
                              "optional": 1,
                              "type": "string"
                            }
                          },
                          "type": "object"
                        }
                      },
                      "POST": {
                        "description": "Start garbage collection.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Start garbage collection.",
                          "properties": {
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/gc",
                    "text": "gc"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "List backup groups.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List backup groups.",
                          "properties": {
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Returns the list of backup groups.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Basic information about a backup group.",
                            "properties": {
                              "backup-count": {
                                "description": "Number of contained snapshots",
                                "type": "integer"
                              },
                              "backup-id": {
                                "description": "Backup ID.",
                                "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                                "type": "string"
                              },
                              "backup-type": {
                                "description": "Backup type.",
                                "enum": [
                                  "vm",
                                  "ct",
                                  "host"
                                ],
                                "type": "string"
                              },
                              "files": {
                                "description": "List of contained archive files.",
                                "items": {
                                  "description": "Backup archive name.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "type": "array"
                              },
                              "last-backup": {
                                "description": "Backup time (Unix epoch.)",
                                "minimum": 1547797308,
                                "type": "integer"
                              },
                              "owner": {
                                "description": "Authentication ID",
                                "maxLength": 64,
                                "minLength": 3,
                                "optional": 1,
                                "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/groups",
                    "text": "groups"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Get \"notes\" for a specific backup",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get \"notes\" for a specific backup",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "PUT": {
                        "description": "Set \"notes\" for a specific backup",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Set \"notes\" for a specific backup",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "notes": {
                              "description": "A multiline text.",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Modify",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/notes",
                    "text": "notes"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Prune the datastore.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Prune the datastore.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "dry-run": {
                              "description": "Just show what prune would do, but do not delete anything.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "keep-daily": {
                              "description": "Number of daily backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "keep-hourly": {
                              "description": "Number of hourly backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "keep-last": {
                              "description": "Number of backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "keep-monthly": {
                              "description": "Number of monthly backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "keep-weekly": {
                              "description": "Number of weekly backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "keep-yearly": {
                              "description": "Number of yearly backups to keep.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Modify",
                              "Datastore.Prune"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Returns the list of snapshots and a flag indicating if there are kept or removed.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Prune result.",
                            "properties": {
                              "backup-id": {
                                "description": "Backup ID.",
                                "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                                "type": "string"
                              },
                              "backup-time": {
                                "description": "Backup time (Unix epoch.)",
                                "minimum": 1547797308,
                                "type": "integer"
                              },
                              "backup-type": {
                                "description": "Backup type.",
                                "enum": [
                                  "vm",
                                  "ct",
                                  "host"
                                ],
                                "type": "string"
                              },
                              "keep": {
                                "description": "Keep snapshot",
                                "type": "boolean"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/prune",
                    "text": "prune"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Download single file from pxar file of a backup snapshot. Only works if it's not encrypted.",
                        "method": "DOWNLOAD",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Download single file from pxar file of a backup snapshot. Only works if it's not encrypted.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "filepath": {
                              "description": "Base64 encoded path",
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Read",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/pxar-file-download",
                    "text": "pxar-file-download"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Read datastore stats",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Read datastore stats",
                          "properties": {
                            "cf": {
                              "description": "",
                              "enum": [
                                "MAX",
                                "AVERAGE"
                              ],
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "timeframe": {
                              "description": "",
                              "enum": [
                                "hour",
                                "day",
                                "week",
                                "month",
                                "year"
                              ],
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/rrd",
                    "text": "rrd"
                  },
                  {
                    "info": {
                      "DELETE": {
                        "description": "Delete backup snapshot.",
                        "method": "DELETE",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Delete backup snapshot.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Modify",
                              "Datastore.Prune"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "GET": {
                        "description": "List backup snapshots.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List backup snapshots.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "optional": 1,
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Returns the list of snapshots.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Basic information about backup snapshot.",
                            "properties": {
                              "backup-id": {
                                "description": "Backup ID.",
                                "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                                "type": "string"
                              },
                              "backup-time": {
                                "description": "Backup time (Unix epoch.)",
                                "minimum": 1547797308,
                                "type": "integer"
                              },
                              "backup-type": {
                                "description": "Backup type.",
                                "enum": [
                                  "vm",
                                  "ct",
                                  "host"
                                ],
                                "type": "string"
                              },
                              "comment": {
                                "description": "Comment (single line).",
                                "optional": 1,
                                "pattern": "/^[[:^cntrl:]]*$/",
                                "type": "string"
                              },
                              "files": {
                                "description": "List of contained archive files.",
                                "items": {
                                  "description": "Backup archive name.",
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "type": "array"
                              },
                              "fingerprint": {
                                "description": "Fingerprint of encryption key",
                                "optional": 1,
                                "type": "string"
                              },
                              "owner": {
                                "description": "Authentication ID",
                                "maxLength": 64,
                                "minLength": 3,
                                "optional": 1,
                                "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                                "type": "string"
                              },
                              "size": {
                                "description": "Overall snapshot size (sum of all archive sizes).",
                                "minimum": 0,
                                "optional": 1,
                                "type": "integer"
                              },
                              "verification": {
                                "additionalProperties": false,
                                "description": "Task properties.",
                                "optional": 1,
                                "properties": {
                                  "state": {
                                    "description": "Result of a verify operation.",
                                    "enum": [
                                      "ok",
                                      "failed"
                                    ],
                                    "type": "string"
                                  },
                                  "upid": {
                                    "description": "Unique Process/Task ID.",
                                    "maxLength": 256,
                                    "type": "string"
                                  }
                                },
                                "type": "object"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/snapshots",
                    "text": "snapshots"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Get datastore status.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get datastore status.",
                          "properties": {
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "verbose": {
                              "default": false,
                              "description": "Include additional information like snapshot counts and GC status.",
                              "optional": 1,
                              "type": "boolean"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Audit",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Overall Datastore status and useful information.",
                          "properties": {
                            "avail": {
                              "description": "Available space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "counts": {
                              "additionalProperties": false,
                              "description": "Counts of groups/snapshots per BackupType.",
                              "optional": 1,
                              "properties": {
                                "ct": {
                                  "additionalProperties": false,
                                  "description": "Backup Type group/snapshot counts.",
                                  "optional": 1,
                                  "properties": {
                                    "groups": {
                                      "description": "The number of groups of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    },
                                    "snapshots": {
                                      "description": "The number of snapshots of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    }
                                  },
                                  "type": "object"
                                },
                                "host": {
                                  "additionalProperties": false,
                                  "description": "Backup Type group/snapshot counts.",
                                  "optional": 1,
                                  "properties": {
                                    "groups": {
                                      "description": "The number of groups of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    },
                                    "snapshots": {
                                      "description": "The number of snapshots of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    }
                                  },
                                  "type": "object"
                                },
                                "other": {
                                  "additionalProperties": false,
                                  "description": "Backup Type group/snapshot counts.",
                                  "optional": 1,
                                  "properties": {
                                    "groups": {
                                      "description": "The number of groups of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    },
                                    "snapshots": {
                                      "description": "The number of snapshots of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    }
                                  },
                                  "type": "object"
                                },
                                "vm": {
                                  "additionalProperties": false,
                                  "description": "Backup Type group/snapshot counts.",
                                  "optional": 1,
                                  "properties": {
                                    "groups": {
                                      "description": "The number of groups of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    },
                                    "snapshots": {
                                      "description": "The number of snapshots of the type.",
                                      "minimum": 0,
                                      "type": "integer"
                                    }
                                  },
                                  "type": "object"
                                }
                              },
                              "type": "object"
                            },
                            "gc-status": {
                              "additionalProperties": false,
                              "description": "Garbage collection status.",
                              "optional": 1,
                              "properties": {
                                "disk-bytes": {
                                  "description": "Bytes used on disk.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "disk-chunks": {
                                  "description": "Chunks used on disk.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "index-data-bytes": {
                                  "description": "Sum of bytes referred by index files.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "index-file-count": {
                                  "description": "Number of processed index files.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "pending-bytes": {
                                  "description": "Sum of pending bytes (pending removal - kept for safety).",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "pending-chunks": {
                                  "description": "Number of pending chunks (pending removal - kept for safety).",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "removed-bad": {
                                  "description": "Number of chunks marked as .bad by verify that have been removed by GC.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "removed-bytes": {
                                  "description": "Sum of removed bytes.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "removed-chunks": {
                                  "description": "Number of removed chunks.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "still-bad": {
                                  "description": "Number of chunks still marked as .bad after garbage collection.",
                                  "minimum": 0,
                                  "type": "integer"
                                },
                                "upid": {
                                  "description": "Unique Process/Task ID.",
                                  "maxLength": 256,
                                  "optional": 1,
                                  "type": "string"
                                }
                              },
                              "type": "object"
                            },
                            "total": {
                              "description": "Total space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "used": {
                              "description": "Used space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            }
                          },
                          "type": "object"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/status",
                    "text": "status"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Upload the client backup log file into a backup snapshot ('client.log.blob').",
                        "method": "UPLOAD",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Upload the client backup log file into a backup snapshot ('client.log.blob').",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Backup"
                            ]
                          },
                          "description": "Only the backup creator/owner is allowed to do this."
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/upload-backup-log",
                    "text": "upload-backup-log"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Verify backups.\n\nThis function can verify a single backup snapshot, all backup from a backup group,\nor all backups in the datastore.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Verify backups.\n\nThis function can verify a single backup snapshot, all backup from a backup group,\nor all backups in the datastore.",
                          "properties": {
                            "backup-id": {
                              "description": "Backup ID.",
                              "optional": 1,
                              "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                              "type": "string"
                            },
                            "backup-time": {
                              "description": "Backup time (Unix epoch.)",
                              "minimum": 1547797308,
                              "optional": 1,
                              "type": "integer"
                            },
                            "backup-type": {
                              "description": "Backup type.",
                              "enum": [
                                "vm",
                                "ct",
                                "host"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "store": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": true,
                            "path": [
                              "datastore",
                              "{store}"
                            ],
                            "privs": [
                              "Datastore.Verify",
                              "Datastore.Backup"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/datastore/{store}/verify",
                    "text": "verify"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/admin/datastore/{store}",
                "text": "{store}"
              }
            ],
            "info": {
              "GET": {
                "description": "Datastore list",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Datastore list",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "description": "List the accessible datastores.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Basic information about a datastore.",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/admin/datastore",
            "text": "datastore"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "POST": {
                        "description": "Runs the sync jobs manually.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Runs the sync jobs manually.",
                          "properties": {
                            "id": {
                              "description": "Job ID.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "description": "User needs Datastore.Backup on target datastore, and Remote.Read on source remote. Additionally, remove_vanished requires Datastore.Prune, and any owner other than the user themselves requires Datastore.Modify",
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/sync/{id}/run",
                    "text": "run"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/admin/sync/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all sync jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all sync jobs",
                  "properties": {
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Limited to sync jobs where user has Datastore.Audit on target datastore, and Remote.Audit on source remote.",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured jobs and their status.",
                  "items": {
                    "additionalProperties": true,
                    "description": "Status of Sync Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "last-run-endtime": {
                        "description": "Endtime of the last run.",
                        "optional": 1,
                        "type": "integer"
                      },
                      "last-run-state": {
                        "description": "Result of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "last-run-upid": {
                        "description": "Task UPID of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "next-run": {
                        "description": "Estimated time of the next run (UNIX epoch).",
                        "optional": 1,
                        "type": "integer"
                      },
                      "owner": {
                        "description": "Authentication ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                        "type": "string"
                      },
                      "remote": {
                        "description": "Remote ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "remote-store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "remove-vanished": {
                        "default": true,
                        "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "schedule": {
                        "description": "Run sync job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/admin/sync",
            "text": "sync"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "POST": {
                        "description": "Runs a verification job manually.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Runs a verification job manually.",
                          "properties": {
                            "id": {
                              "description": "Job ID.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "description": "Requires Datastore.Verify on job's datastore.",
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/admin/verify/{id}/run",
                    "text": "run"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/admin/verify/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all verification jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all verification jobs",
                  "properties": {
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Requires Datastore.Audit or Datastore.Verify on datastore.",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured jobs and their status (filtered by access)",
                  "items": {
                    "additionalProperties": true,
                    "description": "Status of Verification Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "ignore-verified": {
                        "default": true,
                        "description": "Do not verify backups that are already verified if their verification is not outdated.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "last-run-endtime": {
                        "description": "Endtime of the last run.",
                        "optional": 1,
                        "type": "integer"
                      },
                      "last-run-state": {
                        "description": "Result of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "last-run-upid": {
                        "description": "Task UPID of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "next-run": {
                        "description": "Estimated time of the next run (UNIX epoch).",
                        "optional": 1,
                        "type": "integer"
                      },
                      "outdated-after": {
                        "description": "Days after that a verification becomes outdated",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "schedule": {
                        "description": "Run verify job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/admin/verify",
            "text": "verify"
          }
        ],
        "info": {
          "GET": {
            "description": "Directory index.",
            "method": "GET",
            "parameters": {
              "additionalProperties": true,
              "description": "Directory index.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 0,
        "path": "/admin",
        "text": "admin"
      },
      {
        "info": {
          "GET": {
            "description": "Upgraded to backup protocol ('proxmox-backup-protocol-v1').",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Upgraded to backup protocol ('proxmox-backup-protocol-v1').",
              "properties": {
                "backup-id": {
                  "description": "Backup ID.",
                  "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                  "type": "string"
                },
                "backup-time": {
                  "description": "Backup time (Unix epoch.)",
                  "minimum": 1547797308,
                  "type": "integer"
                },
                "backup-type": {
                  "description": "Backup type.",
                  "enum": [
                    "vm",
                    "ct",
                    "host"
                  ],
                  "type": "string"
                },
                "benchmark": {
                  "description": "Job is a benchmark (do not keep data).",
                  "optional": 1,
                  "type": "boolean"
                },
                "debug": {
                  "description": "Enable verbose debug logging.",
                  "optional": 1,
                  "type": "boolean"
                },
                "store": {
                  "description": "Datastore name.",
                  "maxLength": 32,
                  "minLength": 3,
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "permissions": {
              "description": "The user needs Datastore.Backup privilege on /datastore/{store} and needs to own the backup group.",
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup",
        "text": "backup"
      },
      {
        "children": [
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "GET": {
                        "description": "Get the TFA configuration.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get the TFA configuration.",
                          "properties": {}
                        },
                        "permissions": {
                          "user": "all"
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Server side webauthn server configuration.",
                          "optional": 1,
                          "properties": {
                            "id": {
                              "description": "Relying part ID. Must be the domain name without protocol, port or location.\n\nChanging this *will* break existing credentials.",
                              "type": "string"
                            },
                            "origin": {
                              "description": "Site origin. Must be a `https://` URL (or `http://localhost`). Should contain the address\nusers type in their browsers to access the web interface.\n\nChanging this *may* break existing credentials.",
                              "type": "string"
                            },
                            "rp": {
                              "description": "Relying party name. Any text identifier.\n\nChanging this *may* break existing credentials.",
                              "type": "string"
                            }
                          },
                          "type": "object"
                        }
                      },
                      "PUT": {
                        "description": "Update the TFA configuration.",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": true,
                          "description": "Update the TFA configuration.",
                          "properties": {
                            "digest": {
                              "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                              "optional": 1,
                              "pattern": "/^[a-f0-9]{64}$/",
                              "type": "string"
                            },
                            "id": {
                              "description": "Relying part ID. Must be the domain name without protocol, port or location.\n\nChanging this *will* break existing credentials.",
                              "optional": 1,
                              "type": "string"
                            },
                            "origin": {
                              "description": "Site origin. Must be a `https://` URL (or `http://localhost`). Should contain the address\nusers type in their browsers to access the web interface.\n\nChanging this *may* break existing credentials.",
                              "optional": 1,
                              "type": "string"
                            },
                            "rp": {
                              "description": "Relying party name. Any text identifier.\n\nChanging this *may* break existing credentials.",
                              "optional": 1,
                              "type": "string"
                            }
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/config/access/tfa/webauthn",
                    "text": "webauthn"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/config/access/tfa",
                "text": "tfa"
              }
            ],
            "info": {
              "GET": {
                "description": "Directory index.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Directory index.",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/access",
            "text": "access"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Delete a tape changer configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Delete a tape changer configuration",
                      "properties": {
                        "name": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Get tape changer configuration",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Get tape changer configuration",
                      "properties": {
                        "name": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "SCSI tape changer",
                      "properties": {
                        "export-slots": {
                          "description": "A list of slot numbers, comma separated. Those slots are reserved for\nImport/Export, i.e. any media in those slots are considered to be\n'offline'.\n",
                          "format": {
                            "description": "Slot list.",
                            "items": {
                              "description": "Slot number",
                              "minimum": 1,
                              "type": "integer"
                            },
                            "type": "array"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[<integer>, ...]"
                        },
                        "name": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "path": {
                          "description": "Path to Linux generic SCSI device (e.g. '/dev/sg4')",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update a tape changer configuration",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update a tape changer configuration",
                      "properties": {
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "export-slots"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "export-slots": {
                          "description": "A list of slot numbers, comma separated. Those slots are reserved for\nImport/Export, i.e. any media in those slots are considered to be\n'offline'.\n",
                          "format": {
                            "description": "Slot list.",
                            "items": {
                              "description": "Slot number",
                              "minimum": 1,
                              "type": "integer"
                            },
                            "type": "array"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[<integer>, ...]"
                        },
                        "name": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "path": {
                          "description": "Path to Linux generic SCSI device (e.g. '/dev/sg4')",
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/changer/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List changers",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List changers",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured tape changer filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured changers (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "SCSI tape changer",
                    "properties": {
                      "export-slots": {
                        "description": "A list of slot numbers, comma separated. Those slots are reserved for\nImport/Export, i.e. any media in those slots are considered to be\n'offline'.\n",
                        "format": {
                          "description": "Slot list.",
                          "items": {
                            "description": "Slot number",
                            "minimum": 1,
                            "type": "integer"
                          },
                          "type": "array"
                        },
                        "optional": 1,
                        "type": "string",
                        "typetext": "[<integer>, ...]"
                      },
                      "name": {
                        "description": "Tape Changer Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "path": {
                        "description": "Path to Linux generic SCSI device (e.g. '/dev/sg4')",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new changer device",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create a new changer device",
                  "properties": {
                    "export-slots": {
                      "description": "A list of slot numbers, comma separated. Those slots are reserved for\nImport/Export, i.e. any media in those slots are considered to be\n'offline'.\n",
                      "format": {
                        "description": "Slot list.",
                        "items": {
                          "description": "Slot number",
                          "minimum": 1,
                          "type": "integer"
                        },
                        "type": "array"
                      },
                      "optional": 1,
                      "type": "string",
                      "typetext": "[<integer>, ...]"
                    },
                    "name": {
                      "description": "Tape Changer Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "Path to Linux generic SCSI device (e.g. '/dev/sg4')",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "device"
                    ],
                    "privs": [
                      "Tape.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/changer",
            "text": "changer"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Remove a datastore configuration.",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a datastore configuration.",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "datastore",
                          "{name}"
                        ],
                        "privs": [
                          "Datastore.Allocate"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read a datastore configuration.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read a datastore configuration.",
                      "properties": {
                        "name": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "datastore",
                          "{name}"
                        ],
                        "privs": [
                          "Datastore.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Datastore configuration properties.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "gc-schedule": {
                          "description": "Run garbage collection job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "keep-daily": {
                          "description": "Number of daily backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-hourly": {
                          "description": "Number of hourly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-last": {
                          "description": "Number of backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-monthly": {
                          "description": "Number of monthly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-weekly": {
                          "description": "Number of weekly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-yearly": {
                          "description": "Number of yearly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "name": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "notify": {
                          "description": "Datastore notification setting",
                          "format": {
                            "additionalProperties": false,
                            "description": "Datastore notify settings",
                            "properties": {
                              "gc": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "sync": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "verify": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[[gc=<enum>] [,sync=<enum>] [,verify=<enum>]]"
                        },
                        "notify-user": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "path": {
                          "description": "Directory name",
                          "type": "string"
                        },
                        "prune-schedule": {
                          "description": "Run prune job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "verify-new": {
                          "description": "If enabled, all backups will be verified right after completion.",
                          "optional": 1,
                          "type": "boolean"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update datastore config.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update datastore config.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "comment",
                              "gc-schedule",
                              "prune-schedule",
                              "keep-last",
                              "keep-hourly",
                              "keep-daily",
                              "keep-weekly",
                              "keep-monthly",
                              "keep-yearly",
                              "verify-new",
                              "notify-user",
                              "notify"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "gc-schedule": {
                          "description": "Run garbage collection job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "keep-daily": {
                          "description": "Number of daily backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-hourly": {
                          "description": "Number of hourly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-last": {
                          "description": "Number of backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-monthly": {
                          "description": "Number of monthly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-weekly": {
                          "description": "Number of weekly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "keep-yearly": {
                          "description": "Number of yearly backups to keep.",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "name": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "notify": {
                          "description": "Datastore notification setting",
                          "format": {
                            "additionalProperties": false,
                            "description": "Datastore notify settings",
                            "properties": {
                              "gc": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "sync": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "verify": {
                                "description": "When do we send notifications",
                                "enum": [
                                  "never",
                                  "always",
                                  "error"
                                ],
                                "optional": 1,
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[[gc=<enum>] [,sync=<enum>] [,verify=<enum>]]"
                        },
                        "notify-user": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "prune-schedule": {
                          "description": "Run prune job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "verify-new": {
                          "default": false,
                          "description": "If enabled, all new backups will be verified right after completion.",
                          "optional": 1,
                          "type": "boolean"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "datastore",
                          "{name}"
                        ],
                        "privs": [
                          "Datastore.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/datastore/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all datastores",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all datastores",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "description": "List the configured datastores (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "Datastore configuration properties.",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "gc-schedule": {
                        "description": "Run garbage collection job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "keep-daily": {
                        "description": "Number of daily backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "keep-hourly": {
                        "description": "Number of hourly backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "keep-last": {
                        "description": "Number of backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "keep-monthly": {
                        "description": "Number of monthly backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "keep-weekly": {
                        "description": "Number of weekly backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "keep-yearly": {
                        "description": "Number of yearly backups to keep.",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "name": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "notify": {
                        "description": "Datastore notification setting",
                        "format": {
                          "additionalProperties": false,
                          "description": "Datastore notify settings",
                          "properties": {
                            "gc": {
                              "description": "When do we send notifications",
                              "enum": [
                                "never",
                                "always",
                                "error"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "sync": {
                              "description": "When do we send notifications",
                              "enum": [
                                "never",
                                "always",
                                "error"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "verify": {
                              "description": "When do we send notifications",
                              "enum": [
                                "never",
                                "always",
                                "error"
                              ],
                              "optional": 1,
                              "type": "string"
                            }
                          },
                          "type": "object"
                        },
                        "optional": 1,
                        "type": "string",
                        "typetext": "[[gc=<enum>] [,sync=<enum>] [,verify=<enum>]]"
                      },
                      "notify-user": {
                        "description": "User ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "path": {
                        "description": "Directory name",
                        "type": "string"
                      },
                      "prune-schedule": {
                        "description": "Run prune job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "verify-new": {
                        "description": "If enabled, all backups will be verified right after completion.",
                        "optional": 1,
                        "type": "boolean"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create new datastore config.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create new datastore config.",
                  "properties": {
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "gc-schedule": {
                      "description": "Run garbage collection job at specified schedule.",
                      "optional": 1,
                      "type": "string",
                      "typetext": "<calendar-event>"
                    },
                    "keep-daily": {
                      "description": "Number of daily backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "keep-hourly": {
                      "description": "Number of hourly backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "keep-last": {
                      "description": "Number of backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "keep-monthly": {
                      "description": "Number of monthly backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "keep-weekly": {
                      "description": "Number of weekly backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "keep-yearly": {
                      "description": "Number of yearly backups to keep.",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "name": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "notify": {
                      "description": "Datastore notification setting",
                      "format": {
                        "additionalProperties": false,
                        "description": "Datastore notify settings",
                        "properties": {
                          "gc": {
                            "description": "When do we send notifications",
                            "enum": [
                              "never",
                              "always",
                              "error"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "sync": {
                            "description": "When do we send notifications",
                            "enum": [
                              "never",
                              "always",
                              "error"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "verify": {
                            "description": "When do we send notifications",
                            "enum": [
                              "never",
                              "always",
                              "error"
                            ],
                            "optional": 1,
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "optional": 1,
                      "type": "string",
                      "typetext": "[[gc=<enum>] [,sync=<enum>] [,verify=<enum>]]"
                    },
                    "notify-user": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "Directory name",
                      "type": "string"
                    },
                    "prune-schedule": {
                      "description": "Run prune job at specified schedule.",
                      "optional": 1,
                      "type": "string",
                      "typetext": "<calendar-event>"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "datastore"
                    ],
                    "privs": [
                      "Datastore.Allocate"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/datastore",
            "text": "datastore"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Delete a drive configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Delete a drive configuration",
                      "properties": {
                        "name": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Get drive configuration",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Get drive configuration",
                      "properties": {
                        "name": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Lto SCSI tape driver",
                      "properties": {
                        "changer": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "changer-drivenum": {
                          "default": 0,
                          "description": "Associated changer drive number (requires option changer)",
                          "maximum": 8,
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "name": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "path": {
                          "description": "The path to a LTO SCSI-generic tape device (i.e. '/dev/sg0')",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update a drive configuration",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update a drive configuration",
                      "properties": {
                        "changer": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "changer-drivenum": {
                          "default": 0,
                          "description": "Associated changer drive number (requires option changer)",
                          "maximum": 8,
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "changer",
                              "changer-drivenum"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "path": {
                          "description": "The path to a LTO SCSI-generic tape device (i.e. '/dev/sg0')",
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "device",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/drive/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List drives",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List drives",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured tape drives filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured drives (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "Lto SCSI tape driver",
                    "properties": {
                      "changer": {
                        "description": "Tape Changer Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "changer-drivenum": {
                        "default": 0,
                        "description": "Associated changer drive number (requires option changer)",
                        "maximum": 8,
                        "minimum": 0,
                        "optional": 1,
                        "type": "integer"
                      },
                      "name": {
                        "description": "Drive Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "path": {
                        "description": "The path to a LTO SCSI-generic tape device (i.e. '/dev/sg0')",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new drive",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create a new drive",
                  "properties": {
                    "changer": {
                      "description": "Tape Changer Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "changer-drivenum": {
                      "default": 0,
                      "description": "Associated changer drive number (requires option changer)",
                      "maximum": 8,
                      "minimum": 0,
                      "optional": 1,
                      "type": "integer"
                    },
                    "name": {
                      "description": "Drive Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "path": {
                      "description": "The path to a LTO SCSI-generic tape device (i.e. '/dev/sg0')",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "device"
                    ],
                    "privs": [
                      "Tape.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/drive",
            "text": "drive"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Delete a media pool configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Delete a media pool configuration",
                      "properties": {
                        "name": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Get media pool configuration",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Get media pool configuration",
                      "properties": {
                        "name": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Media pool configuration",
                      "properties": {
                        "allocation": {
                          "description": "Media set allocation policy ('continue', 'always', or a calendar event).",
                          "optional": 1,
                          "type": "string"
                        },
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "encrypt": {
                          "description": "Tape encryption key fingerprint (sha256).",
                          "optional": 1,
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "retention": {
                          "description": "Media retention policy ('overwrite', 'keep', or time span).",
                          "optional": 1,
                          "type": "string"
                        },
                        "template": {
                          "description": "Media set naming template (may contain strftime() time format specifications).",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update media pool settings",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update media pool settings",
                      "properties": {
                        "allocation": {
                          "description": "Media set allocation policy ('continue', 'always', or a calendar event).",
                          "optional": 1,
                          "type": "string"
                        },
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "allocation",
                              "retention",
                              "template",
                              "encrypt",
                              "comment"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "encrypt": {
                          "description": "Tape encryption key fingerprint (sha256).",
                          "optional": 1,
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "retention": {
                          "description": "Media retention policy ('overwrite', 'keep', or time span).",
                          "optional": 1,
                          "type": "string"
                        },
                        "template": {
                          "description": "Media set naming template (may contain strftime() time format specifications).",
                          "maxLength": 64,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool",
                          "{name}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/media-pool/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List media pools",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List media pools",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured media pools filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured media pools (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "Media pool configuration",
                    "properties": {
                      "allocation": {
                        "description": "Media set allocation policy ('continue', 'always', or a calendar event).",
                        "optional": 1,
                        "type": "string"
                      },
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "encrypt": {
                        "description": "Tape encryption key fingerprint (sha256).",
                        "optional": 1,
                        "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                        "type": "string"
                      },
                      "name": {
                        "description": "Media pool name.",
                        "maxLength": 32,
                        "minLength": 2,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "retention": {
                        "description": "Media retention policy ('overwrite', 'keep', or time span).",
                        "optional": 1,
                        "type": "string"
                      },
                      "template": {
                        "description": "Media set naming template (may contain strftime() time format specifications).",
                        "maxLength": 64,
                        "minLength": 2,
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new media pool",
                "method": "POST",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Create a new media pool",
                  "properties": {
                    "allocation": {
                      "description": "Media set allocation policy ('continue', 'always', or a calendar event).",
                      "optional": 1,
                      "type": "string"
                    },
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "encrypt": {
                      "description": "Tape encryption key fingerprint (sha256).",
                      "optional": 1,
                      "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                      "type": "string"
                    },
                    "name": {
                      "description": "Media pool name.",
                      "maxLength": 32,
                      "minLength": 2,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "retention": {
                      "description": "Media retention policy ('overwrite', 'keep', or time span).",
                      "optional": 1,
                      "type": "string"
                    },
                    "template": {
                      "description": "Media set naming template (may contain strftime() time format specifications).",
                      "maxLength": 64,
                      "minLength": 2,
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "pool"
                    ],
                    "privs": [
                      "Tape.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/media-pool",
            "text": "media-pool"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "GET": {
                        "description": "List datastores of a remote.cfg entry",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List datastores of a remote.cfg entry",
                          "properties": {
                            "name": {
                              "description": "Remote ID.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "remote",
                              "{name}"
                            ],
                            "privs": [
                              "Remote.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "List the accessible datastores.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Basic information about a datastore.",
                            "properties": {
                              "comment": {
                                "description": "Comment (single line).",
                                "optional": 1,
                                "pattern": "/^[[:^cntrl:]]*$/",
                                "type": "string"
                              },
                              "store": {
                                "description": "Datastore name.",
                                "maxLength": 32,
                                "minLength": 3,
                                "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/config/remote/{name}/scan",
                    "text": "scan"
                  }
                ],
                "info": {
                  "DELETE": {
                    "description": "Remove a remote from the configuration file.",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a remote from the configuration file.",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "remote",
                          "{name}"
                        ],
                        "privs": [
                          "Remote.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read remote configuration data.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read remote configuration data.",
                      "properties": {
                        "name": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "remote",
                          "{name}"
                        ],
                        "privs": [
                          "Remote.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Remote properties.",
                      "properties": {
                        "auth-id": {
                          "description": "Authentication ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                          "type": "string"
                        },
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "fingerprint": {
                          "description": "X509 certificate fingerprint (sha256).",
                          "optional": 1,
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "host": {
                          "description": "DNS name or IP address.",
                          "pattern": "/^(?:(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?)\\.)*(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?))|(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))))$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "password": {
                          "description": "Password or auth token for remote host.",
                          "maxLength": 1024,
                          "minLength": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "port": {
                          "description": "The (optional) port",
                          "optional": 1,
                          "type": "integer"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update remote configuration.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update remote configuration.",
                      "properties": {
                        "auth-id": {
                          "description": "Authentication ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                          "type": "string"
                        },
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "comment",
                              "fingerprint",
                              "port"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "fingerprint": {
                          "description": "X509 certificate fingerprint (sha256).",
                          "optional": 1,
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "host": {
                          "description": "DNS name or IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?)\\.)*(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?))|(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))))$/",
                          "type": "string"
                        },
                        "name": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "password": {
                          "description": "Password or auth token for remote host.",
                          "maxLength": 1024,
                          "minLength": 1,
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "port": {
                          "description": "The (optional) port.",
                          "optional": 1,
                          "type": "integer"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "remote",
                          "{name}"
                        ],
                        "privs": [
                          "Remote.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/config/remote/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all remotes",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all remotes",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured remotes filtered by Remote.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured remotes (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "Remote properties.",
                    "properties": {
                      "auth-id": {
                        "description": "Authentication ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                        "type": "string"
                      },
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "fingerprint": {
                        "description": "X509 certificate fingerprint (sha256).",
                        "optional": 1,
                        "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                        "type": "string"
                      },
                      "host": {
                        "description": "DNS name or IP address.",
                        "pattern": "/^(?:(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?)\\.)*(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?))|(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))))$/",
                        "type": "string"
                      },
                      "name": {
                        "description": "Remote ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "password": {
                        "description": "Password or auth token for remote host.",
                        "maxLength": 1024,
                        "minLength": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "port": {
                        "description": "The (optional) port",
                        "optional": 1,
                        "type": "integer"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create new remote.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create new remote.",
                  "properties": {
                    "auth-id": {
                      "description": "Authentication ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                      "type": "string"
                    },
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "fingerprint": {
                      "description": "X509 certificate fingerprint (sha256).",
                      "optional": 1,
                      "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                      "type": "string"
                    },
                    "host": {
                      "description": "DNS name or IP address.",
                      "pattern": "/^(?:(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?)\\.)*(?:[a-zA-Z0-9](?:[a-zA-Z0-9\\-]*[a-zA-Z0-9])?))|(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))))$/",
                      "type": "string"
                    },
                    "name": {
                      "description": "Remote ID.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "password": {
                      "description": "Password or auth token for remote host.",
                      "maxLength": 1024,
                      "minLength": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "port": {
                      "default": 8007,
                      "description": "The (optional) port.",
                      "optional": 1,
                      "type": "integer"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "remote"
                    ],
                    "privs": [
                      "Remote.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/remote",
            "text": "remote"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Remove a sync job configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a sync job configuration",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "User needs Datastore.Backup on target datastore, and Remote.Read on source remote. Additionally, remove_vanished requires Datastore.Prune, and any owner other than the user themselves requires Datastore.Modify",
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read a sync job configuration.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read a sync job configuration.",
                      "properties": {
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "Limited to sync job entries where user has Datastore.Audit on target datastore, and Remote.Audit on source remote.",
                      "user": "all"
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Sync Job",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "owner": {
                          "description": "Authentication ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                          "type": "string"
                        },
                        "remote": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "remote-store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "remove-vanished": {
                          "default": true,
                          "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "schedule": {
                          "description": "Run sync job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update sync job config.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update sync job config.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "owner",
                              "comment",
                              "schedule",
                              "remove-vanished"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "owner": {
                          "description": "Authentication ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                          "type": "string"
                        },
                        "remote": {
                          "description": "Remote ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "remote-store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "remove-vanished": {
                          "default": true,
                          "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "schedule": {
                          "description": "Run sync job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "User needs Datastore.Backup on target datastore, and Remote.Read on source remote. Additionally, remove_vanished requires Datastore.Prune, and any owner other than the user themselves requires Datastore.Modify",
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/sync/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all sync jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all sync jobs",
                  "properties": {}
                },
                "permissions": {
                  "description": "Limited to sync job entries where user has Datastore.Audit on target datastore, and Remote.Audit on source remote.",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured jobs.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Sync Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "owner": {
                        "description": "Authentication ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                        "type": "string"
                      },
                      "remote": {
                        "description": "Remote ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "remote-store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "remove-vanished": {
                        "default": true,
                        "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "schedule": {
                        "description": "Run sync job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new sync job.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create a new sync job.",
                  "properties": {
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "id": {
                      "description": "Job ID.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "owner": {
                      "description": "Authentication ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                      "type": "string"
                    },
                    "remote": {
                      "description": "Remote ID.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "remote-store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "remove-vanished": {
                      "default": true,
                      "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "schedule": {
                      "description": "Run sync job at specified schedule.",
                      "optional": 1,
                      "type": "string",
                      "typetext": "<calendar-event>"
                    },
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "User needs Datastore.Backup on target datastore, and Remote.Read on source remote. Additionally, remove_vanished requires Datastore.Prune, and any owner other than the user themselves requires Datastore.Modify",
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/sync",
            "text": "sync"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Remove a tape backup job configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a tape backup job configuration",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "job",
                          "{id}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read a tape backup job configuration.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read a tape backup job configuration.",
                      "properties": {
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "job",
                          "{id}"
                        ],
                        "privs": [
                          "Tape.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": true,
                      "description": "Tape Backup Job",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "drive": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "eject-media": {
                          "description": "Eject media upon job completion.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "export-media-set": {
                          "description": "Export media set upon job completion.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "latest-only": {
                          "description": "Backup latest snapshots only.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "notify-user": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "pool": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "schedule": {
                          "description": "Run sync job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update the tape backup job",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update the tape backup job",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "comment",
                              "schedule",
                              "eject-media",
                              "export-media-set",
                              "latest-only",
                              "notify-user"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "drive": {
                          "description": "Drive Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "eject-media": {
                          "description": "Eject media upon job completion.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "export-media-set": {
                          "description": "Export media set upon job completion.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "latest-only": {
                          "description": "Backup latest snapshots only.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "notify-user": {
                          "description": "User ID",
                          "maxLength": 64,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "pool": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "schedule": {
                          "description": "Run sync job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "job",
                          "{id}"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/tape-backup-job/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all tape backup jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all tape backup jobs",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured tape jobs filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured jobs.",
                  "items": {
                    "additionalProperties": true,
                    "description": "Tape Backup Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "drive": {
                        "description": "Drive Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "eject-media": {
                        "description": "Eject media upon job completion.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "export-media-set": {
                        "description": "Export media set upon job completion.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "latest-only": {
                        "description": "Backup latest snapshots only.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "notify-user": {
                        "description": "User ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "pool": {
                        "description": "Media pool name.",
                        "maxLength": 32,
                        "minLength": 2,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "schedule": {
                        "description": "Run sync job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new tape backup job.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Create a new tape backup job.",
                  "properties": {
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "drive": {
                      "description": "Drive Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "eject-media": {
                      "description": "Eject media upon job completion.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "export-media-set": {
                      "description": "Export media set upon job completion.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "id": {
                      "description": "Job ID.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "latest-only": {
                      "description": "Backup latest snapshots only.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "notify-user": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "pool": {
                      "description": "Media pool name.",
                      "maxLength": 32,
                      "minLength": 2,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "schedule": {
                      "description": "Run sync job at specified schedule.",
                      "optional": 1,
                      "type": "string",
                      "typetext": "<calendar-event>"
                    },
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "job"
                    ],
                    "privs": [
                      "Tape.Modify"
                    ]
                  }
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/tape-backup-job",
            "text": "tape-backup-job"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Remove a encryption key from the database\n\nPlease note that you can no longer access tapes using this key.",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a encryption key from the database\n\nPlease note that you can no longer access tapes using this key.",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "fingerprint": {
                          "description": "Tape encryption key fingerprint (sha256).",
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Get key config (public key part)",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Get key config (public key part)",
                      "properties": {
                        "fingerprint": {
                          "description": "Tape encryption key fingerprint (sha256).",
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool"
                        ],
                        "privs": [
                          "Tape.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Encryption Key Information",
                      "properties": {
                        "created": {
                          "description": "Key creation time",
                          "type": "integer"
                        },
                        "fingerprint": {
                          "description": "X509 certificate fingerprint (sha256).",
                          "optional": 1,
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "hint": {
                          "description": "Password hint",
                          "optional": 1,
                          "type": "string"
                        },
                        "kdf": {
                          "default": "scrypt",
                          "description": "Key derivation function for password protected encryption keys.",
                          "enum": [
                            "none",
                            "scrypt",
                            "pbkdf2"
                          ],
                          "type": "string"
                        },
                        "modified": {
                          "description": "Key modification time",
                          "type": "integer"
                        },
                        "path": {
                          "description": "Path to key (if stored in a file)",
                          "optional": 1,
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Change the encryption key's password (and password hint).",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Change the encryption key's password (and password hint).",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "fingerprint": {
                          "description": "Tape encryption key fingerprint (sha256).",
                          "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                          "type": "string"
                        },
                        "hint": {
                          "description": "Password hint.",
                          "maxLength": 64,
                          "minLength": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "kdf": {
                          "default": "scrypt",
                          "description": "Key derivation function for password protected encryption keys.",
                          "enum": [
                            "none",
                            "scrypt",
                            "pbkdf2"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "new-password": {
                          "description": "The new password.",
                          "minLength": 5,
                          "type": "string"
                        },
                        "password": {
                          "description": "The current password.",
                          "minLength": 5,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "tape",
                          "pool"
                        ],
                        "privs": [
                          "Tape.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/tape-encryption-keys/{fingerprint}",
                "text": "{fingerprint}"
              }
            ],
            "info": {
              "GET": {
                "description": "List existing keys",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List existing keys",
                  "properties": {}
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "pool"
                    ],
                    "privs": [
                      "Tape.Audit"
                    ]
                  }
                },
                "returns": {
                  "description": "The list of tape encryption keys (with config digest).",
                  "items": {
                    "additionalProperties": false,
                    "description": "Encryption Key Information",
                    "properties": {
                      "created": {
                        "description": "Key creation time",
                        "type": "integer"
                      },
                      "fingerprint": {
                        "description": "X509 certificate fingerprint (sha256).",
                        "optional": 1,
                        "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                        "type": "string"
                      },
                      "hint": {
                        "description": "Password hint",
                        "optional": 1,
                        "type": "string"
                      },
                      "kdf": {
                        "default": "scrypt",
                        "description": "Key derivation function for password protected encryption keys.",
                        "enum": [
                          "none",
                          "scrypt",
                          "pbkdf2"
                        ],
                        "type": "string"
                      },
                      "modified": {
                        "description": "Key modification time",
                        "type": "integer"
                      },
                      "path": {
                        "description": "Path to key (if stored in a file)",
                        "optional": 1,
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new encryption key",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create a new encryption key",
                  "properties": {
                    "hint": {
                      "description": "Password hint.",
                      "maxLength": 64,
                      "minLength": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "kdf": {
                      "default": "scrypt",
                      "description": "Key derivation function for password protected encryption keys.",
                      "enum": [
                        "none",
                        "scrypt",
                        "pbkdf2"
                      ],
                      "optional": 1,
                      "type": "string"
                    },
                    "password": {
                      "description": "A secret password.",
                      "minLength": 5,
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "check": {
                    "partial": false,
                    "path": [
                      "tape",
                      "pool"
                    ],
                    "privs": [
                      "Tape.Modify"
                    ]
                  }
                },
                "returns": {
                  "description": "Tape encryption key fingerprint (sha256).",
                  "pattern": "/^(?:[0-9a-fA-F][0-9a-fA-F])(?::[0-9a-fA-F][0-9a-fA-F]){31}$/",
                  "type": "string"
                }
              }
            },
            "leaf": 0,
            "path": "/config/tape-encryption-keys",
            "text": "tape-encryption-keys"
          },
          {
            "children": [
              {
                "info": {
                  "DELETE": {
                    "description": "Remove a verification job configuration",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Remove a verification job configuration",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "Requires Datastore.Verify on job's datastore.",
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read a verification job configuration.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read a verification job configuration.",
                      "properties": {
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "Requires Datastore.Audit or Datastore.Verify on job's datastore.",
                      "user": "all"
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Verification Job",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "ignore-verified": {
                          "default": true,
                          "description": "Do not verify backups that are already verified if their verification is not outdated.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "outdated-after": {
                          "description": "Days after that a verification becomes outdated",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "schedule": {
                          "description": "Run verify job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update verification job config.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update verification job config.",
                      "properties": {
                        "comment": {
                          "description": "Comment (single line).",
                          "optional": 1,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        },
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "ignore-verified",
                              "comment",
                              "schedule",
                              "outdated-after"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "ignore-verified": {
                          "default": true,
                          "description": "Do not verify backups that are already verified if their verification is not outdated.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "outdated-after": {
                          "description": "Days after that a verification becomes outdated",
                          "minimum": 1,
                          "optional": 1,
                          "type": "integer"
                        },
                        "schedule": {
                          "description": "Run verify job at specified schedule.",
                          "optional": 1,
                          "type": "string",
                          "typetext": "<calendar-event>"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "Requires Datastore.Verify on job's datastore.",
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/config/verify/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all verification jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all verification jobs",
                  "properties": {}
                },
                "permissions": {
                  "description": "Requires Datastore.Audit or Datastore.Verify on datastore.",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured jobs.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Verification Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "ignore-verified": {
                        "default": true,
                        "description": "Do not verify backups that are already verified if their verification is not outdated.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "outdated-after": {
                        "description": "Days after that a verification becomes outdated",
                        "minimum": 1,
                        "optional": 1,
                        "type": "integer"
                      },
                      "schedule": {
                        "description": "Run verify job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Create a new verification job.",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Create a new verification job.",
                  "properties": {
                    "comment": {
                      "description": "Comment (single line).",
                      "optional": 1,
                      "pattern": "/^[[:^cntrl:]]*$/",
                      "type": "string"
                    },
                    "id": {
                      "description": "Job ID.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "ignore-verified": {
                      "default": true,
                      "description": "Do not verify backups that are already verified if their verification is not outdated.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "outdated-after": {
                      "description": "Days after that a verification becomes outdated",
                      "minimum": 1,
                      "optional": 1,
                      "type": "integer"
                    },
                    "schedule": {
                      "description": "Run verify job at specified schedule.",
                      "optional": 1,
                      "type": "string",
                      "typetext": "<calendar-event>"
                    },
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "Requires Datastore.Verify on job's datastore.",
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/config/verify",
            "text": "verify"
          }
        ],
        "info": {
          "GET": {
            "description": "Directory index.",
            "method": "GET",
            "parameters": {
              "additionalProperties": true,
              "description": "Directory index.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 0,
        "path": "/config",
        "text": "config"
      },
      {
        "children": [
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "GET": {
                        "description": "Retrieve the changelog of the specified package.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Retrieve the changelog of the specified package.",
                          "properties": {
                            "name": {
                              "description": "Package name to get changelog of.",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "version": {
                              "description": "Package version to get changelog of. Omit to use candidate version.",
                              "optional": 1,
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/apt/changelog",
                    "text": "changelog"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "List available APT updates",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List available APT updates",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "A list of packages with available updates.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Describes a package for which an update is available.",
                            "properties": {
                              "Arch": {
                                "description": "Package architecture",
                                "type": "string"
                              },
                              "ChangeLogUrl": {
                                "description": "URL under which the package's changelog can be retrieved",
                                "type": "string"
                              },
                              "Description": {
                                "description": "Human readable package description",
                                "type": "string"
                              },
                              "ExtraInfo": {
                                "description": "Custom extra field for additional package information",
                                "optional": 1,
                                "type": "string"
                              },
                              "OldVersion": {
                                "description": "Old version currently installed",
                                "type": "string"
                              },
                              "Origin": {
                                "description": "Package origin",
                                "type": "string"
                              },
                              "Package": {
                                "description": "Package name",
                                "type": "string"
                              },
                              "Priority": {
                                "description": "Package priority in human-readable form",
                                "type": "string"
                              },
                              "Section": {
                                "description": "Package section",
                                "type": "string"
                              },
                              "Title": {
                                "description": "Package title",
                                "type": "string"
                              },
                              "Version": {
                                "description": "New version to be updated to",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      },
                      "POST": {
                        "description": "Update the APT database",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Update the APT database",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "notify": {
                              "default": false,
                              "description": "Send notification mail about new package updates available to the\n                    email address configured for 'root@pam').",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "quiet": {
                              "default": false,
                              "description": "Only produces output suitable for logging, omitting progress indicators.",
                              "optional": 1,
                              "type": "boolean"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/apt/update",
                    "text": "update"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Get package information for important Proxmox Backup Server packages.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get package information for important Proxmox Backup Server packages.",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "List of more relevant packages.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Describes a package for which an update is available.",
                            "properties": {
                              "Arch": {
                                "description": "Package architecture",
                                "type": "string"
                              },
                              "ChangeLogUrl": {
                                "description": "URL under which the package's changelog can be retrieved",
                                "type": "string"
                              },
                              "Description": {
                                "description": "Human readable package description",
                                "type": "string"
                              },
                              "ExtraInfo": {
                                "description": "Custom extra field for additional package information",
                                "optional": 1,
                                "type": "string"
                              },
                              "OldVersion": {
                                "description": "Old version currently installed",
                                "type": "string"
                              },
                              "Origin": {
                                "description": "Package origin",
                                "type": "string"
                              },
                              "Package": {
                                "description": "Package name",
                                "type": "string"
                              },
                              "Priority": {
                                "description": "Package priority in human-readable form",
                                "type": "string"
                              },
                              "Section": {
                                "description": "Package section",
                                "type": "string"
                              },
                              "Title": {
                                "description": "Package title",
                                "type": "string"
                              },
                              "Version": {
                                "description": "New version to be updated to",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/apt/versions",
                    "text": "versions"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/nodes/{node}/apt",
                "text": "apt"
              },
              {
                "children": [
                  {
                    "children": [
                      {
                        "info": {
                          "DELETE": {
                            "description": "Remove a Filesystem mounted under '/mnt/datastore/<name>'.\".",
                            "method": "DELETE",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Remove a Filesystem mounted under '/mnt/datastore/<name>'.\".",
                              "properties": {
                                "name": {
                                  "description": "Datastore name.",
                                  "maxLength": 32,
                                  "minLength": 3,
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "disks"
                                ],
                                "privs": [
                                  "Sys.Modify"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/disks/directory/{name}",
                        "text": "{name}"
                      }
                    ],
                    "info": {
                      "GET": {
                        "description": "List systemd datastore mount units.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List systemd datastore mount units.",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "List of systemd datastore mount units.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Datastore mount info.",
                            "properties": {
                              "device": {
                                "description": "The mounted device.",
                                "type": "string"
                              },
                              "filesystem": {
                                "description": "",
                                "enum": [
                                  "ext4",
                                  "xfs"
                                ],
                                "optional": 1,
                                "type": "string"
                              },
                              "options": {
                                "description": "Mount options",
                                "optional": 1,
                                "type": "string"
                              },
                              "path": {
                                "description": "The mount path.",
                                "type": "string"
                              },
                              "unitfile": {
                                "description": "The path of the mount unit.",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      },
                      "POST": {
                        "description": "Create a Filesystem on an unused disk. Will be mounted under '/mnt/datastore/<name>'.\".",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Create a Filesystem on an unused disk. Will be mounted under '/mnt/datastore/<name>'.\".",
                          "properties": {
                            "add-datastore": {
                              "description": "Configure a datastore using the directory.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "disk": {
                              "description": "Block device name (/sys/block/<name>).",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(:?(:?h|s|x?v)d[a-z]+)|(:?nvme\\d+n\\d+)$/",
                              "type": "string"
                            },
                            "filesystem": {
                              "description": "",
                              "enum": [
                                "ext4",
                                "xfs"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "name": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/nodes/{node}/disks/directory",
                    "text": "directory"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Initialize empty Disk with GPT",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Initialize empty Disk with GPT",
                          "properties": {
                            "disk": {
                              "description": "Block device name (/sys/block/<name>).",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(:?(:?h|s|x?v)d[a-z]+)|(:?nvme\\d+n\\d+)$/",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "uuid": {
                              "description": "UUID for the GPT table.",
                              "maxLength": 36,
                              "optional": 1,
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/disks/initgpt",
                    "text": "initgpt"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "List local disks",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List local disks",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "skipsmart": {
                              "default": false,
                              "description": "Skip smart checks.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "usage-type": {
                              "description": "",
                              "enum": [
                                "unused",
                                "mounted",
                                "lvm",
                                "zfs",
                                "devicemapper",
                                "partitions"
                              ],
                              "optional": 1,
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Local disk list.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Information about how a Disk is used",
                            "properties": {
                              "devpath": {
                                "description": "Linux device path (/dev/xxx)",
                                "optional": 1,
                                "type": "string"
                              },
                              "disk-type": {
                                "description": "This is just a rough estimate for a \"type\" of disk.",
                                "enum": [
                                  "unknown",
                                  "hdd",
                                  "ssd",
                                  "usb"
                                ],
                                "type": "string"
                              },
                              "gpt": {
                                "description": "Set if disk contains a GPT partition table",
                                "type": "boolean"
                              },
                              "model": {
                                "description": "Model",
                                "optional": 1,
                                "type": "string"
                              },
                              "name": {
                                "description": "Disk name (/sys/block/<name>)",
                                "type": "string"
                              },
                              "rpm": {
                                "description": "RPM",
                                "minimum": 0,
                                "optional": 1,
                                "type": "integer"
                              },
                              "serial": {
                                "description": "Serisal number",
                                "optional": 1,
                                "type": "string"
                              },
                              "size": {
                                "description": "Disk size",
                                "minimum": 0,
                                "type": "integer"
                              },
                              "status": {
                                "description": "SMART status",
                                "enum": [
                                  "passed",
                                  "failed",
                                  "unknown"
                                ],
                                "type": "string"
                              },
                              "used": {
                                "description": "",
                                "enum": [
                                  "unused",
                                  "mounted",
                                  "lvm",
                                  "zfs",
                                  "devicemapper",
                                  "partitions"
                                ],
                                "type": "string"
                              },
                              "vendor": {
                                "description": "Vendor",
                                "optional": 1,
                                "type": "string"
                              },
                              "wearout": {
                                "description": "Disk wearout",
                                "optional": 1,
                                "type": "number"
                              },
                              "wwn": {
                                "description": "WWN",
                                "optional": 1,
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/disks/list",
                    "text": "list"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Get SMART attributes and health of a disk.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get SMART attributes and health of a disk.",
                          "properties": {
                            "disk": {
                              "description": "Block device name (/sys/block/<name>).",
                              "maxLength": 64,
                              "minLength": 3,
                              "pattern": "/^(:?(:?h|s|x?v)d[a-z]+)|(:?nvme\\d+n\\d+)$/",
                              "type": "string"
                            },
                            "healthonly": {
                              "description": "If true returns only the health status.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Data from smartctl",
                          "properties": {
                            "attributes": {
                              "description": "SMART attributes.",
                              "items": {
                                "additionalProperties": false,
                                "description": "SMART Attribute",
                                "properties": {
                                  "flags": {
                                    "description": "ATA Flags",
                                    "optional": 1,
                                    "type": "string"
                                  },
                                  "id": {
                                    "description": "ATA Attribute ID",
                                    "minimum": 0,
                                    "optional": 1,
                                    "type": "integer"
                                  },
                                  "name": {
                                    "description": "Attribute name",
                                    "type": "string"
                                  },
                                  "normalized": {
                                    "description": "ATA normalized value (0..100)",
                                    "optional": 1,
                                    "type": "number"
                                  },
                                  "threshold": {
                                    "description": "ATA threshold",
                                    "optional": 1,
                                    "type": "number"
                                  },
                                  "value": {
                                    "description": "Attribute raw value",
                                    "type": "string"
                                  },
                                  "worst": {
                                    "description": "ATA worst",
                                    "optional": 1,
                                    "type": "number"
                                  }
                                },
                                "type": "object"
                              },
                              "type": "array"
                            },
                            "status": {
                              "description": "SMART status",
                              "enum": [
                                "passed",
                                "failed",
                                "unknown"
                              ],
                              "type": "string"
                            },
                            "wearout": {
                              "description": "Wearout level.",
                              "optional": 1,
                              "type": "number"
                            }
                          },
                          "type": "object"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/disks/smart",
                    "text": "smart"
                  },
                  {
                    "children": [
                      {
                        "info": {
                          "GET": {
                            "description": "Get zpool status details.",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Get zpool status details.",
                              "properties": {
                                "name": {
                                  "description": "ZFS Pool Name",
                                  "pattern": "/^[a-zA-Z][a-z0-9A-Z\\-_.:]+$/",
                                  "type": "string"
                                },
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "disks"
                                ],
                                "privs": [
                                  "Sys.Audit"
                                ]
                              }
                            },
                            "returns": {
                              "additionalProperties": false,
                              "description": "zpool vdev tree with status",
                              "properties": {},
                              "type": "object"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/disks/zfs/{name}",
                        "text": "{name}"
                      }
                    ],
                    "info": {
                      "GET": {
                        "description": "List zfs pools.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List zfs pools.",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "List of zpools.",
                          "items": {
                            "additionalProperties": false,
                            "description": "zpool list item",
                            "properties": {
                              "alloc": {
                                "description": "Used size",
                                "minimum": 0,
                                "type": "integer"
                              },
                              "dedup": {
                                "description": "ZFS deduplication ratio",
                                "type": "number"
                              },
                              "frag": {
                                "description": "ZFS fragnentation level",
                                "minimum": 0,
                                "type": "integer"
                              },
                              "free": {
                                "description": "Free space",
                                "minimum": 0,
                                "type": "integer"
                              },
                              "health": {
                                "description": "Health",
                                "type": "string"
                              },
                              "name": {
                                "description": "zpool name",
                                "type": "string"
                              },
                              "size": {
                                "description": "Total size",
                                "minimum": 0,
                                "type": "integer"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      },
                      "POST": {
                        "description": "Create a new ZFS pool. Will be mounted under '/mnt/datastore/<name>'.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Create a new ZFS pool. Will be mounted under '/mnt/datastore/<name>'.",
                          "properties": {
                            "add-datastore": {
                              "description": "Configure a datastore using the zpool.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "ashift": {
                              "default": 12,
                              "description": "Pool sector size exponent.",
                              "maximum": 16,
                              "minimum": 9,
                              "optional": 1,
                              "type": "integer"
                            },
                            "compression": {
                              "default": "On",
                              "description": "The ZFS compression algorithm to use.",
                              "enum": [
                                "gzip",
                                "lz4",
                                "lzjb",
                                "zle",
                                "on",
                                "off"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "devices": {
                              "description": "A list of disk names, comma separated.",
                              "format": {
                                "description": "Disk name list.",
                                "items": {
                                  "description": "Block device name (/sys/block/<name>).",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(:?(:?h|s|x?v)d[a-z]+)|(:?nvme\\d+n\\d+)$/",
                                  "type": "string"
                                },
                                "type": "array"
                              },
                              "type": "string",
                              "typetext": "[<string>, ...]"
                            },
                            "name": {
                              "description": "Datastore name.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "raidlevel": {
                              "description": "The ZFS RAID level to use.",
                              "enum": [
                                "single",
                                "mirror",
                                "raid10",
                                "raidz",
                                "raidz2",
                                "raidz3"
                              ],
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "disks"
                            ],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/nodes/{node}/disks/zfs",
                    "text": "zfs"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/nodes/{node}/disks",
                "text": "disks"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read DNS settings.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read DNS settings.",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "dns"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Returns DNS server IPs and sreach domain.",
                      "properties": {
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "dns1": {
                          "description": "First name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "dns2": {
                          "description": "Second name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "dns3": {
                          "description": "Third name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "search": {
                          "description": "Search domain for host-name lookup.",
                          "optional": 1,
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Update DNS settings.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Update DNS settings.",
                      "properties": {
                        "delete": {
                          "description": "List of properties to delete.",
                          "items": {
                            "description": "Deletable property name",
                            "enum": [
                              "dns1",
                              "dns2",
                              "dns3"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "digest": {
                          "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                          "optional": 1,
                          "pattern": "/^[a-f0-9]{64}$/",
                          "type": "string"
                        },
                        "dns1": {
                          "description": "First name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "dns2": {
                          "description": "Second name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "dns3": {
                          "description": "Third name server IP address.",
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::))))$/",
                          "type": "string"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "search": {
                          "description": "Search domain for host-name lookup.",
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "dns"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/dns",
                "text": "dns"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read syslog entries.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read syslog entries.",
                      "properties": {
                        "endcursor": {
                          "description": "End before the given Cursor. Conflicts with 'until'",
                          "optional": 1,
                          "type": "string"
                        },
                        "lastentries": {
                          "description": "Limit to the last X lines. Conflicts with a range.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "since": {
                          "description": "Display all log since this UNIX epoch. Conflicts with 'startcursor'.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "startcursor": {
                          "description": "Start after the given Cursor. Conflicts with 'since'.",
                          "optional": 1,
                          "type": "string"
                        },
                        "until": {
                          "description": "Display all log until this UNIX epoch. Conflicts with 'endcursor'.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "log"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "description": "Returns a list of journal entries.",
                      "items": {
                        "description": "Line text.",
                        "type": "string"
                      },
                      "type": "array"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/journal",
                "text": "journal"
              },
              {
                "children": [
                  {
                    "info": {
                      "DELETE": {
                        "description": "Remove network interface configuration.",
                        "method": "DELETE",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Remove network interface configuration.",
                          "properties": {
                            "digest": {
                              "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                              "optional": 1,
                              "pattern": "/^[a-f0-9]{64}$/",
                              "type": "string"
                            },
                            "iface": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "network",
                              "interfaces",
                              "{iface}"
                            ],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "GET": {
                        "description": "Read a network interface configuration.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Read a network interface configuration.",
                          "properties": {
                            "iface": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "network",
                              "interfaces",
                              "{name}"
                            ],
                            "privs": [
                              "Sys.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Network Interface configuration",
                          "properties": {
                            "active": {
                              "description": "Interface is active (UP)",
                              "type": "boolean"
                            },
                            "autostart": {
                              "description": "Autostart interface",
                              "type": "boolean"
                            },
                            "bond-primary": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "optional": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "bond_mode": {
                              "description": "Linux Bond Mode",
                              "enum": [
                                "balance-rr",
                                "active-backup",
                                "balance-xor",
                                "broadcast",
                                "802.3ad",
                                "balance-tlb",
                                "balance-alb"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "bond_xmit_hash_policy": {
                              "description": "Bond Transmit Hash Policy for LACP (802.3ad)",
                              "enum": [
                                "layer2",
                                "layer2+3",
                                "layer3+4"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "bridge_ports": {
                              "description": "Network interface list.",
                              "items": {
                                "description": "Network interface name.",
                                "maxLength": 15,
                                "minLength": 1,
                                "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              },
                              "optional": 1,
                              "type": "array"
                            },
                            "bridge_vlan_aware": {
                              "description": "Enable bridge vlan support.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "cidr": {
                              "description": "IPv4 address with netmask (CIDR notation).",
                              "maxLength": 18,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))/\\d{1,2})$$/",
                              "type": "string"
                            },
                            "cidr6": {
                              "description": "IPv6 address with netmask (CIDR notation).",
                              "maxLength": 43,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))/\\d{1,3})$$/",
                              "type": "string"
                            },
                            "comments": {
                              "description": "Comments (inet, may span multiple lines)",
                              "optional": 1,
                              "type": "string"
                            },
                            "comments6": {
                              "description": "Comments (inet6, may span multiple lines)",
                              "optional": 1,
                              "type": "string"
                            },
                            "gateway": {
                              "description": "IPv4 address.",
                              "maxLength": 15,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))$/",
                              "type": "string"
                            },
                            "gateway6": {
                              "description": "IPv6 address.",
                              "maxLength": 39,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))$/",
                              "type": "string"
                            },
                            "method": {
                              "description": "Interface configuration method",
                              "enum": [
                                "manual",
                                "static",
                                "dhcp",
                                "loopback"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "method6": {
                              "description": "Interface configuration method",
                              "enum": [
                                "manual",
                                "static",
                                "dhcp",
                                "loopback"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "mtu": {
                              "description": "Maximum Transmission Unit",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "name": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "options": {
                              "description": "Option list (inet)",
                              "items": {
                                "description": "Optional attribute line.",
                                "type": "string"
                              },
                              "type": "array"
                            },
                            "options6": {
                              "description": "Option list (inet6)",
                              "items": {
                                "description": "Optional attribute line.",
                                "type": "string"
                              },
                              "type": "array"
                            },
                            "slaves": {
                              "description": "Network interface list.",
                              "items": {
                                "description": "Network interface name.",
                                "maxLength": 15,
                                "minLength": 1,
                                "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              },
                              "optional": 1,
                              "type": "array"
                            },
                            "type": {
                              "description": "Network interface type",
                              "enum": [
                                "loopback",
                                "eth",
                                "bridge",
                                "bond",
                                "vlan",
                                "alias",
                                "unknown"
                              ],
                              "type": "string"
                            }
                          },
                          "type": "object"
                        }
                      },
                      "PUT": {
                        "description": "Update network interface config.",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Update network interface config.",
                          "properties": {
                            "autostart": {
                              "description": "Autostart interface.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "bond-primary": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "optional": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "bond_mode": {
                              "description": "Linux Bond Mode",
                              "enum": [
                                "balance-rr",
                                "active-backup",
                                "balance-xor",
                                "broadcast",
                                "802.3ad",
                                "balance-tlb",
                                "balance-alb"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "bond_xmit_hash_policy": {
                              "description": "Bond Transmit Hash Policy for LACP (802.3ad)",
                              "enum": [
                                "layer2",
                                "layer2+3",
                                "layer3+4"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "bridge_ports": {
                              "description": "A list of network devices, comma separated.",
                              "format": {
                                "description": "Network interface list.",
                                "items": {
                                  "description": "Network interface name.",
                                  "maxLength": 15,
                                  "minLength": 1,
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "type": "array"
                              },
                              "optional": 1,
                              "type": "string",
                              "typetext": "[<string>, ...]"
                            },
                            "bridge_vlan_aware": {
                              "description": "Enable bridge vlan support.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "cidr": {
                              "description": "IPv4 address with netmask (CIDR notation).",
                              "maxLength": 18,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))/\\d{1,2})$$/",
                              "type": "string"
                            },
                            "cidr6": {
                              "description": "IPv6 address with netmask (CIDR notation).",
                              "maxLength": 43,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))/\\d{1,3})$$/",
                              "type": "string"
                            },
                            "comments": {
                              "description": "Comments (inet, may span multiple lines)",
                              "optional": 1,
                              "type": "string"
                            },
                            "comments6": {
                              "description": "Comments (inet5, may span multiple lines)",
                              "optional": 1,
                              "type": "string"
                            },
                            "delete": {
                              "description": "List of properties to delete.",
                              "items": {
                                "description": "Deletable property name",
                                "enum": [
                                  "cidr",
                                  "cidr6",
                                  "gateway",
                                  "gateway6",
                                  "method",
                                  "method6",
                                  "comments",
                                  "comments6",
                                  "mtu",
                                  "autostart",
                                  "bridge_ports",
                                  "bridge_vlan_aware",
                                  "slaves",
                                  "bond-primary",
                                  "bond_xmit_hash_policy"
                                ],
                                "type": "string"
                              },
                              "optional": 1,
                              "type": "array"
                            },
                            "digest": {
                              "description": "Prevent changes if current configuration file has different SHA256 digest. This can be used to prevent concurrent modifications.",
                              "optional": 1,
                              "pattern": "/^[a-f0-9]{64}$/",
                              "type": "string"
                            },
                            "gateway": {
                              "description": "IPv4 address.",
                              "maxLength": 15,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))$/",
                              "type": "string"
                            },
                            "gateway6": {
                              "description": "IPv6 address.",
                              "maxLength": 39,
                              "optional": 1,
                              "pattern": "/^(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))$/",
                              "type": "string"
                            },
                            "iface": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "method": {
                              "description": "Interface configuration method",
                              "enum": [
                                "manual",
                                "static",
                                "dhcp",
                                "loopback"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "method6": {
                              "description": "Interface configuration method",
                              "enum": [
                                "manual",
                                "static",
                                "dhcp",
                                "loopback"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "mtu": {
                              "default": 1500,
                              "description": "Maximum Transmission Unit.",
                              "maximum": 65535,
                              "minimum": 46,
                              "optional": 1,
                              "type": "integer"
                            },
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "slaves": {
                              "description": "A list of network devices, comma separated.",
                              "format": {
                                "description": "Network interface list.",
                                "items": {
                                  "description": "Network interface name.",
                                  "maxLength": 15,
                                  "minLength": 1,
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "type": "array"
                              },
                              "optional": 1,
                              "type": "string",
                              "typetext": "[<string>, ...]"
                            },
                            "type": {
                              "description": "Network interface type",
                              "enum": [
                                "loopback",
                                "eth",
                                "bridge",
                                "bond",
                                "vlan",
                                "alias",
                                "unknown"
                              ],
                              "optional": 1,
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "system",
                              "network",
                              "interfaces",
                              "{iface}"
                            ],
                            "privs": [
                              "Sys.Modify"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/nodes/{node}/network/{iface}",
                    "text": "{iface}"
                  }
                ],
                "info": {
                  "DELETE": {
                    "description": "Revert network configuration (rm /etc/network/interfaces.new).",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Revert network configuration (rm /etc/network/interfaces.new).",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "interfaces"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "List all datastores",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "List all datastores",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "interfaces"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "description": "List network devices (with config digest).",
                      "items": {
                        "additionalProperties": false,
                        "description": "Network Interface configuration",
                        "properties": {
                          "active": {
                            "description": "Interface is active (UP)",
                            "type": "boolean"
                          },
                          "autostart": {
                            "description": "Autostart interface",
                            "type": "boolean"
                          },
                          "bond-primary": {
                            "description": "Network interface name.",
                            "maxLength": 15,
                            "minLength": 1,
                            "optional": 1,
                            "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                            "type": "string"
                          },
                          "bond_mode": {
                            "description": "Linux Bond Mode",
                            "enum": [
                              "balance-rr",
                              "active-backup",
                              "balance-xor",
                              "broadcast",
                              "802.3ad",
                              "balance-tlb",
                              "balance-alb"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "bond_xmit_hash_policy": {
                            "description": "Bond Transmit Hash Policy for LACP (802.3ad)",
                            "enum": [
                              "layer2",
                              "layer2+3",
                              "layer3+4"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "bridge_ports": {
                            "description": "Network interface list.",
                            "items": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "optional": 1,
                            "type": "array"
                          },
                          "bridge_vlan_aware": {
                            "description": "Enable bridge vlan support.",
                            "optional": 1,
                            "type": "boolean"
                          },
                          "cidr": {
                            "description": "IPv4 address with netmask (CIDR notation).",
                            "maxLength": 18,
                            "optional": 1,
                            "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))/\\d{1,2})$$/",
                            "type": "string"
                          },
                          "cidr6": {
                            "description": "IPv6 address with netmask (CIDR notation).",
                            "maxLength": 43,
                            "optional": 1,
                            "pattern": "/^(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))/\\d{1,3})$$/",
                            "type": "string"
                          },
                          "comments": {
                            "description": "Comments (inet, may span multiple lines)",
                            "optional": 1,
                            "type": "string"
                          },
                          "comments6": {
                            "description": "Comments (inet6, may span multiple lines)",
                            "optional": 1,
                            "type": "string"
                          },
                          "gateway": {
                            "description": "IPv4 address.",
                            "maxLength": 15,
                            "optional": 1,
                            "pattern": "/^(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))$/",
                            "type": "string"
                          },
                          "gateway6": {
                            "description": "IPv6 address.",
                            "maxLength": 39,
                            "optional": 1,
                            "pattern": "/^(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))$/",
                            "type": "string"
                          },
                          "method": {
                            "description": "Interface configuration method",
                            "enum": [
                              "manual",
                              "static",
                              "dhcp",
                              "loopback"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "method6": {
                            "description": "Interface configuration method",
                            "enum": [
                              "manual",
                              "static",
                              "dhcp",
                              "loopback"
                            ],
                            "optional": 1,
                            "type": "string"
                          },
                          "mtu": {
                            "description": "Maximum Transmission Unit",
                            "minimum": 0,
                            "optional": 1,
                            "type": "integer"
                          },
                          "name": {
                            "description": "Network interface name.",
                            "maxLength": 15,
                            "minLength": 1,
                            "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                            "type": "string"
                          },
                          "options": {
                            "description": "Option list (inet)",
                            "items": {
                              "description": "Optional attribute line.",
                              "type": "string"
                            },
                            "type": "array"
                          },
                          "options6": {
                            "description": "Option list (inet6)",
                            "items": {
                              "description": "Optional attribute line.",
                              "type": "string"
                            },
                            "type": "array"
                          },
                          "slaves": {
                            "description": "Network interface list.",
                            "items": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "optional": 1,
                            "type": "array"
                          },
                          "type": {
                            "description": "Network interface type",
                            "enum": [
                              "loopback",
                              "eth",
                              "bridge",
                              "bond",
                              "vlan",
                              "alias",
                              "unknown"
                            ],
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "type": "array"
                    }
                  },
                  "POST": {
                    "description": "Create network interface configuration.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Create network interface configuration.",
                      "properties": {
                        "autostart": {
                          "description": "Autostart interface.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "bond-primary": {
                          "description": "Network interface name.",
                          "maxLength": 15,
                          "minLength": 1,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "bond_mode": {
                          "description": "Linux Bond Mode",
                          "enum": [
                            "balance-rr",
                            "active-backup",
                            "balance-xor",
                            "broadcast",
                            "802.3ad",
                            "balance-tlb",
                            "balance-alb"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "bond_xmit_hash_policy": {
                          "description": "Bond Transmit Hash Policy for LACP (802.3ad)",
                          "enum": [
                            "layer2",
                            "layer2+3",
                            "layer3+4"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "bridge_ports": {
                          "description": "A list of network devices, comma separated.",
                          "format": {
                            "description": "Network interface list.",
                            "items": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "type": "array"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[<string>, ...]"
                        },
                        "bridge_vlan_aware": {
                          "description": "Enable bridge vlan support.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "cidr": {
                          "description": "IPv4 address with netmask (CIDR notation).",
                          "maxLength": 18,
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))/\\d{1,2})$$/",
                          "type": "string"
                        },
                        "cidr6": {
                          "description": "IPv6 address with netmask (CIDR notation).",
                          "maxLength": 43,
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))/\\d{1,3})$$/",
                          "type": "string"
                        },
                        "comments": {
                          "description": "Comments (inet, may span multiple lines)",
                          "optional": 1,
                          "type": "string"
                        },
                        "comments6": {
                          "description": "Comments (inet5, may span multiple lines)",
                          "optional": 1,
                          "type": "string"
                        },
                        "gateway": {
                          "description": "IPv4 address.",
                          "maxLength": 15,
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))$/",
                          "type": "string"
                        },
                        "gateway6": {
                          "description": "IPv6 address.",
                          "maxLength": 39,
                          "optional": 1,
                          "pattern": "/^(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){6})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:::(?:(?:[0-9a-fA-F]{1,4}):){5})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){4})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,1}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){3})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,2}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){2})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,3}(?:[0-9a-fA-F]{1,4}))?::(?:(?:[0-9a-fA-F]{1,4}):){1})(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,4}(?:[0-9a-fA-F]{1,4}))?::)(?:(?:(?:(?:(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9])\\.){3}(?:25[0-5]|(?:2[0-4]|1[0-9]|[1-9])?[0-9]))|(?:[0-9a-fA-F]{1,4}):(?:[0-9a-fA-F]{1,4}))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,5}(?:[0-9a-fA-F]{1,4}))?::)(?:[0-9a-fA-F]{1,4}))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4}):){0,6}(?:[0-9a-fA-F]{1,4}))?::)))$/",
                          "type": "string"
                        },
                        "iface": {
                          "description": "Network interface name.",
                          "maxLength": 15,
                          "minLength": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "method": {
                          "description": "Interface configuration method",
                          "enum": [
                            "manual",
                            "static",
                            "dhcp",
                            "loopback"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "method6": {
                          "description": "Interface configuration method",
                          "enum": [
                            "manual",
                            "static",
                            "dhcp",
                            "loopback"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "mtu": {
                          "default": 1500,
                          "description": "Maximum Transmission Unit.",
                          "maximum": 65535,
                          "minimum": 46,
                          "optional": 1,
                          "type": "integer"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "slaves": {
                          "description": "A list of network devices, comma separated.",
                          "format": {
                            "description": "Network interface list.",
                            "items": {
                              "description": "Network interface name.",
                              "maxLength": 15,
                              "minLength": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "type": "array"
                          },
                          "optional": 1,
                          "type": "string",
                          "typetext": "[<string>, ...]"
                        },
                        "type": {
                          "description": "Network interface type",
                          "enum": [
                            "loopback",
                            "eth",
                            "bridge",
                            "bond",
                            "vlan",
                            "alias",
                            "unknown"
                          ],
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "interfaces",
                          "{iface}"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "PUT": {
                    "description": "Reload network configuration (requires ifupdown2).",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Reload network configuration (requires ifupdown2).",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "network",
                          "interfaces"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/nodes/{node}/network",
                "text": "network"
              },
              {
                "info": {
                  "GET": {
                    "description": "Generate a report",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Generate a report",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "status"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "description": "Returns report of the node",
                      "type": "string"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/report",
                "text": "report"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read node stats",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read node stats",
                      "properties": {
                        "cf": {
                          "description": "",
                          "enum": [
                            "MAX",
                            "AVERAGE"
                          ],
                          "type": "string"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "timeframe": {
                          "description": "",
                          "enum": [
                            "hour",
                            "day",
                            "week",
                            "month",
                            "year"
                          ],
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "status"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/rrd",
                "text": "rrd"
              },
              {
                "children": [
                  {
                    "children": [
                      {
                        "info": {
                          "POST": {
                            "description": "Reload service.",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Reload service.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "service": {
                                  "description": "Service ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "services",
                                  "{service}"
                                ],
                                "privs": [
                                  "Sys.Modify"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/services/{service}/reload",
                        "text": "reload"
                      },
                      {
                        "info": {
                          "POST": {
                            "description": "Retart service.",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Retart service.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "service": {
                                  "description": "Service ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "services",
                                  "{service}"
                                ],
                                "privs": [
                                  "Sys.Modify"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/services/{service}/restart",
                        "text": "restart"
                      },
                      {
                        "info": {
                          "POST": {
                            "description": "Start service.",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Start service.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "service": {
                                  "description": "Service ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "services",
                                  "{service}"
                                ],
                                "privs": [
                                  "Sys.Modify"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/services/{service}/start",
                        "text": "start"
                      },
                      {
                        "info": {
                          "GET": {
                            "description": "Read service properties.",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Read service properties.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "service": {
                                  "description": "Service ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "services",
                                  "{service}"
                                ],
                                "privs": [
                                  "Sys.Audit"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/services/{service}/state",
                        "text": "state"
                      },
                      {
                        "info": {
                          "POST": {
                            "description": "Stop service.",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Stop service.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "service": {
                                  "description": "Service ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "check": {
                                "partial": false,
                                "path": [
                                  "system",
                                  "services",
                                  "{service}"
                                ],
                                "privs": [
                                  "Sys.Modify"
                                ]
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/services/{service}/stop",
                        "text": "stop"
                      }
                    ],
                    "info": {
                      "GET": {
                        "description": "Directory index.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": true,
                          "description": "Directory index.",
                          "properties": {}
                        },
                        "permissions": {
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/nodes/{node}/services/{service}",
                    "text": "{service}"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Service list.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Service list.",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "services"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "description": "Returns a list of systemd services.",
                      "items": {
                        "additionalProperties": false,
                        "description": "Service details.",
                        "properties": {
                          "desc": {
                            "description": "systemd service description.",
                            "type": "string"
                          },
                          "name": {
                            "description": "systemd service name.",
                            "type": "string"
                          },
                          "service": {
                            "description": "Service ID.",
                            "maxLength": 256,
                            "type": "string"
                          },
                          "state": {
                            "description": "systemd service 'SubState'.",
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "type": "array"
                    }
                  }
                },
                "leaf": 0,
                "path": "/nodes/{node}/services",
                "text": "services"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read node memory, CPU and (root) disk usage",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read node memory, CPU and (root) disk usage",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "status"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "The Node status",
                      "properties": {
                        "cpu": {
                          "description": "Total CPU usage since last query.",
                          "type": "number"
                        },
                        "cpuinfo": {
                          "additionalProperties": false,
                          "description": "Information about the CPU",
                          "properties": {
                            "cpus": {
                              "description": "The number of CPU cores (incl. threads)",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "model": {
                              "description": "The CPU model",
                              "type": "string"
                            },
                            "sockets": {
                              "description": "The number of CPU sockets",
                              "minimum": 0,
                              "type": "integer"
                            }
                          },
                          "type": "object"
                        },
                        "info": {
                          "additionalProperties": false,
                          "description": "Contains general node information such as the fingerprint`",
                          "properties": {
                            "fingerprint": {
                              "description": "The SSL Fingerprint",
                              "type": "string"
                            }
                          },
                          "type": "object"
                        },
                        "kversion": {
                          "description": "The current kernel version.",
                          "type": "string"
                        },
                        "loadavg": {
                          "description": "Load for 1, 5 and 15 minutes.",
                          "items": {
                            "description": "the load",
                            "type": "number"
                          },
                          "type": "array"
                        },
                        "memory": {
                          "additionalProperties": false,
                          "description": "Node memory usage counters",
                          "properties": {
                            "free": {
                              "description": "Free memory",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "total": {
                              "description": "Total memory",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "used": {
                              "description": "Used memory",
                              "minimum": 0,
                              "type": "integer"
                            }
                          },
                          "type": "object"
                        },
                        "root": {
                          "additionalProperties": false,
                          "description": "Storage space usage information.",
                          "properties": {
                            "avail": {
                              "description": "Available space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "total": {
                              "description": "Total space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "used": {
                              "description": "Used space (bytes).",
                              "minimum": 0,
                              "type": "integer"
                            }
                          },
                          "type": "object"
                        },
                        "swap": {
                          "additionalProperties": false,
                          "description": "Node swap usage counters",
                          "properties": {
                            "free": {
                              "description": "Free swap",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "total": {
                              "description": "Total swap",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "used": {
                              "description": "Used swap",
                              "minimum": 0,
                              "type": "integer"
                            }
                          },
                          "type": "object"
                        },
                        "uptime": {
                          "description": "The current uptime of the server.",
                          "minimum": 0,
                          "type": "integer"
                        },
                        "wait": {
                          "description": "Total IO wait since last query.",
                          "type": "number"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "POST": {
                    "description": "Reboot or shutdown the node.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Reboot or shutdown the node.",
                      "properties": {
                        "command": {
                          "description": "Node Power command type.",
                          "enum": [
                            "reboot",
                            "shutdown"
                          ],
                          "type": "string"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "status"
                        ],
                        "privs": [
                          "Sys.PowerManagement"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/status",
                "text": "status"
              },
              {
                "info": {
                  "DELETE": {
                    "description": "Delete subscription info.",
                    "method": "DELETE",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Delete subscription info.",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "GET": {
                    "description": "Read subscription info.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read subscription info.",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Proxmox subscription information",
                      "properties": {
                        "checktime": {
                          "description": "timestamp of the last check done",
                          "optional": 1,
                          "type": "integer"
                        },
                        "key": {
                          "description": "the subscription key, if set and permitted to access",
                          "optional": 1,
                          "type": "string"
                        },
                        "message": {
                          "description": "a more human readable status message",
                          "optional": 1,
                          "type": "string"
                        },
                        "nextduedate": {
                          "description": "next due date of the set subscription",
                          "optional": 1,
                          "type": "string"
                        },
                        "productname": {
                          "description": "human readable productname of the set subscription",
                          "optional": 1,
                          "type": "string"
                        },
                        "regdate": {
                          "description": "register date of the set subscription",
                          "optional": 1,
                          "type": "string"
                        },
                        "serverid": {
                          "description": "the server ID, if permitted to access",
                          "optional": 1,
                          "type": "string"
                        },
                        "status": {
                          "description": "Subscription status",
                          "enum": [
                            "new",
                            "notfound",
                            "active",
                            "invalid"
                          ],
                          "type": "string"
                        },
                        "url": {
                          "description": "URL to the web shop",
                          "optional": 1,
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "POST": {
                    "description": "Check and update subscription status.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Check and update subscription status.",
                      "properties": {
                        "force": {
                          "default": false,
                          "description": "Always connect to server, even if information in cache is up to date.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  },
                  "PUT": {
                    "description": "Set a subscription key and check it.",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Set a subscription key and check it.",
                      "properties": {
                        "key": {
                          "description": "Proxmox Backup Server subscription key.",
                          "maxLength": 16,
                          "minLength": 15,
                          "pattern": "/^pbs(?:[cbsp])-[0-9a-f]{10}$/",
                          "type": "string"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/subscription",
                "text": "subscription"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read syslog entries.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read syslog entries.",
                      "properties": {
                        "limit": {
                          "description": "Max. number of lines.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "service": {
                          "description": "Service ID.",
                          "maxLength": 128,
                          "optional": 1,
                          "type": "string"
                        },
                        "since": {
                          "description": "Display all log since this date-time string.",
                          "optional": 1,
                          "pattern": "/^\\d{4}-\\d{2}-\\d{2}( \\d{2}:\\d{2}(:\\d{2})?)?$/",
                          "type": "string"
                        },
                        "start": {
                          "description": "Start line number.",
                          "minimum": 0,
                          "optional": 1,
                          "type": "integer"
                        },
                        "until": {
                          "description": "Display all log until this date-time string.",
                          "optional": 1,
                          "pattern": "/^\\d{4}-\\d{2}-\\d{2}( \\d{2}:\\d{2}(:\\d{2})?)?$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "log"
                        ],
                        "privs": [
                          "Sys.Audit"
                        ]
                      }
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Returns a list of syslog entries.",
                      "properties": {
                        "n": {
                          "description": "Line number.",
                          "type": "integer"
                        },
                        "t": {
                          "description": "Line text.",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/syslog",
                "text": "syslog"
              },
              {
                "children": [
                  {
                    "children": [
                      {
                        "info": {
                          "GET": {
                            "description": "Read task log.",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Read task log.",
                              "properties": {
                                "limit": {
                                  "default": 50,
                                  "description": "Only list this amount of lines.",
                                  "optional": 1,
                                  "type": "integer"
                                },
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "start": {
                                  "default": 0,
                                  "description": "Start at this line.",
                                  "optional": 1,
                                  "type": "integer"
                                },
                                "test-status": {
                                  "description": "Test task status, and set result attribute \"active\" accordingly.",
                                  "optional": 1,
                                  "type": "boolean"
                                },
                                "upid": {
                                  "description": "Unique Process/Task ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "description": "Users can access there own tasks, or need Sys.Audit on /system/tasks.",
                              "user": "all"
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/tasks/{upid}/log",
                        "text": "log"
                      },
                      {
                        "info": {
                          "GET": {
                            "description": "Get task status.",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Get task status.",
                              "properties": {
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "upid": {
                                  "description": "Unique Process/Task ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                }
                              }
                            },
                            "permissions": {
                              "description": "Users can access their own tasks, or need Sys.Audit on /system/tasks.",
                              "user": "all"
                            },
                            "returns": {
                              "additionalProperties": false,
                              "description": "Task status information.",
                              "properties": {
                                "exitstatus": {
                                  "description": "'OK', 'Error: <msg>', or 'unkwown'.",
                                  "optional": 1,
                                  "type": "string"
                                },
                                "id": {
                                  "description": "Worker ID (arbitrary ASCII string)",
                                  "optional": 1,
                                  "type": "string"
                                },
                                "node": {
                                  "description": "Node name (or 'localhost')",
                                  "type": "string"
                                },
                                "pid": {
                                  "description": "The Unix PID.",
                                  "type": "integer"
                                },
                                "pstart": {
                                  "description": "The Unix process start time from `/proc/pid/stat`",
                                  "type": "integer"
                                },
                                "starttime": {
                                  "description": "The task start time (Epoch)",
                                  "type": "integer"
                                },
                                "status": {
                                  "description": "'running' or 'stopped'",
                                  "type": "string"
                                },
                                "tokenid": {
                                  "description": "The token ID part of an API token authentication id.\n\nThis alone does NOT uniquely identify the API token - use a full `Authid` for such use cases.",
                                  "optional": 1,
                                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                },
                                "type": {
                                  "description": "Worker type (arbitrary ASCII string)",
                                  "type": "string"
                                },
                                "upid": {
                                  "description": "Unique Process/Task ID.",
                                  "maxLength": 256,
                                  "type": "string"
                                },
                                "user": {
                                  "description": "User ID",
                                  "maxLength": 64,
                                  "minLength": 3,
                                  "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                  "type": "string"
                                }
                              },
                              "type": "object"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/nodes/{node}/tasks/{upid}/status",
                        "text": "status"
                      }
                    ],
                    "info": {
                      "DELETE": {
                        "description": "Try to stop a task.",
                        "method": "DELETE",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Try to stop a task.",
                          "properties": {
                            "node": {
                              "description": "Node name (or 'localhost')",
                              "type": "string"
                            },
                            "upid": {
                              "description": "Unique Process/Task ID.",
                              "maxLength": 256,
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "description": "Users can stop there own tasks, or need Sys.Modify on /system/tasks.",
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      },
                      "GET": {
                        "description": "Directory index.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": true,
                          "description": "Directory index.",
                          "properties": {}
                        },
                        "permissions": {
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/nodes/{node}/tasks/{upid}",
                    "text": "{upid}"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "List tasks.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "List tasks.",
                      "properties": {
                        "errors": {
                          "default": false,
                          "description": "Only list erroneous tasks.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "limit": {
                          "default": 50,
                          "description": "Only list this amount of tasks. (0 means no limit)",
                          "optional": 1,
                          "type": "integer"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "running": {
                          "default": false,
                          "description": "Only list running tasks.",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "since": {
                          "description": "Only list tasks since this UNIX epoch.",
                          "optional": 1,
                          "type": "integer"
                        },
                        "start": {
                          "default": 0,
                          "description": "List tasks beginning from this offset.",
                          "optional": 1,
                          "type": "integer"
                        },
                        "statusfilter": {
                          "description": "Only list tasks which have any one of the listed status.",
                          "items": {
                            "description": "",
                            "enum": [
                              "ok",
                              "warning",
                              "error",
                              "unknown"
                            ],
                            "type": "string"
                          },
                          "optional": 1,
                          "type": "array"
                        },
                        "store": {
                          "description": "Datastore name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "typefilter": {
                          "description": "Only list tasks whose type contains this.",
                          "optional": 1,
                          "type": "string"
                        },
                        "until": {
                          "description": "Only list tasks until this UNIX epoch.",
                          "optional": 1,
                          "type": "integer"
                        },
                        "userfilter": {
                          "description": "Only list tasks from this user.",
                          "optional": 1,
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "Users can only see there own tasks, unless the have Sys.Audit on /system/tasks.",
                      "user": "all"
                    },
                    "returns": {
                      "description": "A list of tasks.",
                      "items": {
                        "additionalProperties": false,
                        "description": "Task properties.",
                        "properties": {
                          "endtime": {
                            "description": "The task end time (Epoch)",
                            "optional": 1,
                            "type": "integer"
                          },
                          "node": {
                            "description": "The node name where the task is running on.",
                            "type": "string"
                          },
                          "pid": {
                            "description": "The Unix PID",
                            "type": "integer"
                          },
                          "pstart": {
                            "description": "The task start time (Epoch)",
                            "minimum": 0,
                            "type": "integer"
                          },
                          "starttime": {
                            "description": "The task start time (Epoch)",
                            "type": "integer"
                          },
                          "status": {
                            "description": "Task end status",
                            "optional": 1,
                            "type": "string"
                          },
                          "upid": {
                            "description": "Unique Process/Task ID.",
                            "maxLength": 256,
                            "type": "string"
                          },
                          "user": {
                            "description": "Authentication ID",
                            "maxLength": 64,
                            "minLength": 3,
                            "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                            "type": "string"
                          },
                          "worker_id": {
                            "description": "Worker ID (arbitrary ASCII string)",
                            "optional": 1,
                            "type": "string"
                          },
                          "worker_type": {
                            "description": "Worker type (arbitrary ASCII string)",
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "type": "array"
                    }
                  }
                },
                "leaf": 0,
                "path": "/nodes/{node}/tasks",
                "text": "tasks"
              },
              {
                "info": {
                  "POST": {
                    "description": "Call termproxy and return shell ticket",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Call termproxy and return shell ticket",
                      "properties": {
                        "cmd": {
                          "description": "The command to run.",
                          "enum": [
                            "login",
                            "upgrade"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system"
                        ],
                        "privs": [
                          "Sys.Console"
                        ]
                      },
                      "description": "Restricted to users on realm 'pam'"
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Object with the user, ticket, port and upid",
                      "properties": {
                        "port": {
                          "description": "",
                          "type": "string"
                        },
                        "ticket": {
                          "description": "",
                          "type": "string"
                        },
                        "upid": {
                          "description": "",
                          "type": "string"
                        },
                        "user": {
                          "description": "",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/termproxy",
                "text": "termproxy"
              },
              {
                "info": {
                  "GET": {
                    "description": "Read server time and time zone settings.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Read server time and time zone settings.",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "additionalProperties": false,
                      "description": "Returns server time and timezone.",
                      "properties": {
                        "localtime": {
                          "description": "Seconds since 1970-01-01 00:00:00 UTC. (local time)",
                          "minimum": 1297163644,
                          "type": "integer"
                        },
                        "time": {
                          "description": "Seconds since 1970-01-01 00:00:00 UTC.",
                          "minimum": 1297163644,
                          "type": "integer"
                        },
                        "timezone": {
                          "description": "Time zone. The file '/usr/share/zoneinfo/zone.tab' contains the list of valid names.",
                          "maxLength": 64,
                          "minLength": 2,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        }
                      },
                      "type": "object"
                    }
                  },
                  "PUT": {
                    "description": "Set time zone",
                    "method": "PUT",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Set time zone",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "timezone": {
                          "description": "Time zone. The file '/usr/share/zoneinfo/zone.tab' contains the list of valid names.",
                          "maxLength": 64,
                          "minLength": 2,
                          "pattern": "/^[[:^cntrl:]]*$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system",
                          "time"
                        ],
                        "privs": [
                          "Sys.Modify"
                        ]
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/time",
                "text": "time"
              },
              {
                "info": {
                  "GET": {
                    "description": "Upgraded to websocket",
                    "method": "DOWNLOAD",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Upgraded to websocket",
                      "properties": {
                        "node": {
                          "description": "Node name (or 'localhost')",
                          "type": "string"
                        },
                        "port": {
                          "description": "Terminal port",
                          "type": "integer"
                        },
                        "vncticket": {
                          "description": "Terminal ticket",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "check": {
                        "partial": false,
                        "path": [
                          "system"
                        ],
                        "privs": [
                          "Sys.Console"
                        ]
                      },
                      "description": "The user needs Sys.Console on /system."
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/nodes/{node}/vncwebsocket",
                "text": "vncwebsocket"
              }
            ],
            "info": {
              "GET": {
                "description": "Directory index.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Directory index.",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/nodes/{node}",
            "text": "{node}"
          }
        ],
        "info": {},
        "leaf": 0,
        "path": "/nodes",
        "text": "nodes"
      },
      {
        "info": {
          "GET": {
            "description": "Dummy method which replies with `{ \"pong\": True }`",
            "method": "GET",
            "parameters": {
              "additionalProperties": false,
              "description": "Dummy method which replies with `{ \"pong\": True }`",
              "properties": {}
            },
            "permissions": {
              "description": "Anyone can access this, because it's used for a cheap check if the API daemon is online.",
              "user": "world"
            },
            "returns": {
              "additionalProperties": false,
              "description": "Dummy ping",
              "properties": {
                "pong": {
                  "description": "Always true",
                  "type": "boolean"
                }
              },
              "type": "object"
            }
          }
        },
        "leaf": 1,
        "path": "/ping",
        "text": "ping"
      },
      {
        "info": {
          "POST": {
            "description": "Sync store from other repository",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Sync store from other repository",
              "properties": {
                "remote": {
                  "description": "Remote ID.",
                  "maxLength": 32,
                  "minLength": 3,
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                },
                "remote-store": {
                  "description": "Datastore name.",
                  "maxLength": 32,
                  "minLength": 3,
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                },
                "remove-vanished": {
                  "default": true,
                  "description": "Delete vanished backups. This remove the local copy if the remote backup was deleted.",
                  "optional": 1,
                  "type": "boolean"
                },
                "store": {
                  "description": "Datastore name.",
                  "maxLength": 32,
                  "minLength": 3,
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "permissions": {
              "description": "The user needs Datastore.Backup privilege on '/datastore/{store}',\nand needs to own the backup group. Remote.Read is required on '/remote/{remote}/{remote-store}'.\nThe delete flag additionally requires the Datastore.Prune privilege on '/datastore/{store}'.\n",
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/pull",
        "text": "pull"
      },
      {
        "info": {
          "GET": {
            "description": "Upgraded to backup protocol ('proxmox-backup-reader-protocol-v1').",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Upgraded to backup protocol ('proxmox-backup-reader-protocol-v1').",
              "properties": {
                "backup-id": {
                  "description": "Backup ID.",
                  "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                  "type": "string"
                },
                "backup-time": {
                  "description": "Backup time (Unix epoch.)",
                  "minimum": 1547797308,
                  "type": "integer"
                },
                "backup-type": {
                  "description": "Backup type.",
                  "enum": [
                    "vm",
                    "ct",
                    "host"
                  ],
                  "type": "string"
                },
                "debug": {
                  "description": "Enable verbose debug logging.",
                  "optional": 1,
                  "type": "boolean"
                },
                "store": {
                  "description": "Datastore name.",
                  "maxLength": 32,
                  "minLength": 3,
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "permissions": {
              "description": "The user needs Datastore.Read privilege on /datastore/{store}.",
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/reader",
        "text": "reader"
      },
      {
        "children": [
          {
            "info": {
              "GET": {
                "description": "List Datastore usages and estimates",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List Datastore usages and estimates",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "description": "Lists the Status of the Datastores.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Status of a Datastore",
                    "properties": {
                      "avail": {
                        "description": "The available bytes of the underlying storage",
                        "type": "integer"
                      },
                      "estimated-full-date": {
                        "description": "Estimation of the UNIX epoch when the storage will be full.This is calculated via a simple Linear Regression (Least Squares)of RRD data of the last Month. Missing if there are not enough data points yet.If the estimate lies in the past, the usage is decreasing.",
                        "optional": 1,
                        "type": "integer"
                      },
                      "history": {
                        "description": "A list of usages of the past (last Month).",
                        "items": {
                          "description": "The usage of a time in the past. Either null or between 0.0 and 1.0.",
                          "type": "number"
                        },
                        "type": "array"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "total": {
                        "description": "The Size of the underlying storage in bytes",
                        "type": "integer"
                      },
                      "used": {
                        "description": "The used bytes of the underlying storage",
                        "type": "integer"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 1,
            "path": "/status/datastore-usage",
            "text": "datastore-usage"
          }
        ],
        "info": {
          "GET": {
            "description": "Directory index.",
            "method": "GET",
            "parameters": {
              "additionalProperties": true,
              "description": "Directory index.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 0,
        "path": "/status",
        "text": "status"
      },
      {
        "children": [
          {
            "children": [
              {
                "info": {
                  "POST": {
                    "description": "Runs a tape backup job manually.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Runs a tape backup job manually.",
                      "properties": {
                        "id": {
                          "description": "Job ID.",
                          "maxLength": 32,
                          "minLength": 3,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "The user needs Tape.Write privilege on /tape/pool/{pool} and /tape/drive/{drive}, Datastore.Read privilege on /datastore/{store}.",
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/tape/backup/{id}",
                "text": "{id}"
              }
            ],
            "info": {
              "GET": {
                "description": "List all tape backup jobs",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List all tape backup jobs",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured tape jobs filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "List configured thape backup jobs and their status",
                  "items": {
                    "additionalProperties": true,
                    "description": "Status of Tape Backup Job",
                    "properties": {
                      "comment": {
                        "description": "Comment (single line).",
                        "optional": 1,
                        "pattern": "/^[[:^cntrl:]]*$/",
                        "type": "string"
                      },
                      "drive": {
                        "description": "Drive Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "eject-media": {
                        "description": "Eject media upon job completion.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "export-media-set": {
                        "description": "Export media set upon job completion.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "id": {
                        "description": "Job ID.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "last-run-endtime": {
                        "description": "Endtime of the last run.",
                        "optional": 1,
                        "type": "integer"
                      },
                      "last-run-state": {
                        "description": "Result of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "last-run-upid": {
                        "description": "Task UPID of the last run.",
                        "optional": 1,
                        "type": "string"
                      },
                      "latest-only": {
                        "description": "Backup latest snapshots only.",
                        "optional": 1,
                        "type": "boolean"
                      },
                      "next-run": {
                        "description": "Estimated time of the next run (UNIX epoch).",
                        "optional": 1,
                        "type": "integer"
                      },
                      "notify-user": {
                        "description": "User ID",
                        "maxLength": 64,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "pool": {
                        "description": "Media pool name.",
                        "maxLength": 32,
                        "minLength": 2,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "schedule": {
                        "description": "Run sync job at specified schedule.",
                        "optional": 1,
                        "type": "string",
                        "typetext": "<calendar-event>"
                      },
                      "store": {
                        "description": "Datastore name.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              },
              "POST": {
                "description": "Backup datastore to tape media pool",
                "method": "POST",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Backup datastore to tape media pool",
                  "properties": {
                    "drive": {
                      "description": "Drive Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "eject-media": {
                      "description": "Eject media upon job completion.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "export-media-set": {
                      "description": "Export media set upon job completion.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "latest-only": {
                      "description": "Backup latest snapshots only.",
                      "optional": 1,
                      "type": "boolean"
                    },
                    "notify-user": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "pool": {
                      "description": "Media pool name.",
                      "maxLength": 32,
                      "minLength": 2,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "store": {
                      "description": "Datastore name.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "The user needs Tape.Write privilege on /tape/pool/{pool} and /tape/drive/{drive}, Datastore.Read privilege on /datastore/{store}.",
                  "user": "all"
                },
                "returns": {
                  "description": "Unique Process/Task ID.",
                  "maxLength": 256,
                  "type": "string"
                }
              }
            },
            "leaf": 0,
            "path": "/tape/backup",
            "text": "backup"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "GET": {
                        "description": "Get tape changer status",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get tape changer status",
                          "properties": {
                            "cache": {
                              "default": true,
                              "description": "Use cached value.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "name": {
                              "description": "Tape Changer Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{name}"
                            ],
                            "privs": [
                              "Tape.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "A status entry for each drive and slot.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Mtx Status Entry",
                            "properties": {
                              "entry-id": {
                                "description": "The ID of the slot or drive",
                                "minimum": 0,
                                "type": "integer"
                              },
                              "entry-kind": {
                                "description": "Mtx Entry Kind",
                                "enum": [
                                  "drive",
                                  "slot",
                                  "import-export"
                                ],
                                "type": "string"
                              },
                              "label-text": {
                                "description": "Media Label/Barcode.",
                                "maxLength": 32,
                                "minLength": 2,
                                "optional": 1,
                                "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                                "type": "string"
                              },
                              "loaded-slot": {
                                "description": "The slot the drive was loaded from",
                                "minimum": 0,
                                "optional": 1,
                                "type": "integer"
                              },
                              "state": {
                                "description": "The current state of the drive",
                                "optional": 1,
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/changer/{name}/status",
                    "text": "status"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Transfers media from one slot to another",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Transfers media from one slot to another",
                          "properties": {
                            "from": {
                              "description": "Source slot number",
                              "minimum": 1,
                              "type": "integer"
                            },
                            "name": {
                              "description": "Tape Changer Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "to": {
                              "description": "Destination slot number",
                              "minimum": 1,
                              "type": "integer"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{name}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/changer/{name}/transfer",
                    "text": "transfer"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/tape/changer/{name}",
                "text": "{name}"
              }
            ],
            "info": {
              "GET": {
                "description": "List changers",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List changers",
                  "properties": {}
                },
                "permissions": {
                  "description": "List configured tape changer filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured changers with model information.",
                  "items": {
                    "additionalProperties": true,
                    "description": "Changer config with optional device identification attributes",
                    "properties": {
                      "export-slots": {
                        "description": "A list of slot numbers, comma separated. Those slots are reserved for\nImport/Export, i.e. any media in those slots are considered to be\n'offline'.\n",
                        "format": {
                          "description": "Slot list.",
                          "items": {
                            "description": "Slot number",
                            "minimum": 1,
                            "type": "integer"
                          },
                          "type": "array"
                        },
                        "optional": 1,
                        "type": "string",
                        "typetext": "[<integer>, ...]"
                      },
                      "model": {
                        "description": "Model (autodetected)",
                        "optional": 1,
                        "type": "string"
                      },
                      "name": {
                        "description": "Tape Changer Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "path": {
                        "description": "Path to Linux generic SCSI device (e.g. '/dev/sg4')",
                        "type": "string"
                      },
                      "serial": {
                        "description": "Serial number (autodetected)",
                        "optional": 1,
                        "type": "string"
                      },
                      "vendor": {
                        "description": "Vendor (autodetected)",
                        "optional": 1,
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/tape/changer",
            "text": "changer"
          },
          {
            "children": [
              {
                "children": [
                  {
                    "info": {
                      "POST": {
                        "description": "Label media with barcodes from changer device",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Label media with barcodes from changer device",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "pool": {
                              "description": "Media pool name.",
                              "maxLength": 32,
                              "minLength": 2,
                              "optional": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Write"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/barcode-label-media",
                    "text": "barcode-label-media"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Read Cartridge Memory (Medium auxiliary memory attributes)",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Read Cartridge Memory (Medium auxiliary memory attributes)",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "description": "A List of medium auxiliary memory attributes.",
                          "items": {
                            "additionalProperties": false,
                            "description": "Medium auxiliary memory attributes (MAM)",
                            "properties": {
                              "id": {
                                "description": "Attribute id",
                                "maximum": 65535,
                                "minimum": 0,
                                "type": "integer"
                              },
                              "name": {
                                "description": "Attribute name",
                                "type": "string"
                              },
                              "value": {
                                "description": "Attribute value",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/cartridge-memory",
                    "text": "cartridge-memory"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Scan media and record content",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Scan media and record content",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "force": {
                              "description": "Force overriding existing index.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "scan": {
                              "description": "Re-read the whole tape to reconstruct the catalog instead of restoring saved versions.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "verbose": {
                              "description": "Verbose mode - log all found chunks.",
                              "optional": 1,
                              "type": "boolean"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/catalog",
                    "text": "catalog"
                  },
                  {
                    "info": {
                      "PUT": {
                        "description": "Clean drive",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Clean drive",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/clean",
                    "text": "clean"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Eject/Unload drive media",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Eject/Unload drive media",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/eject-media",
                    "text": "eject-media"
                  },
                  {
                    "info": {
                      "PUT": {
                        "description": "Export media with specified label",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Export media with specified label",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "label-text": {
                              "description": "Media Label/Barcode.",
                              "maxLength": 32,
                              "minLength": 2,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "The import-export slot number the media was transferred to.",
                          "minimum": 1,
                          "type": "integer"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/export-media",
                    "text": "export-media"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Format media. Check for label-text if given (cancels if wrong media).",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Format media. Check for label-text if given (cancels if wrong media).",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "fast": {
                              "default": true,
                              "description": "Use fast erase.",
                              "optional": 1,
                              "type": "boolean"
                            },
                            "label-text": {
                              "description": "Media Label/Barcode.",
                              "maxLength": 32,
                              "minLength": 2,
                              "optional": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Write"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/format-media",
                    "text": "format-media"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "List known media labels (Changer Inventory)\n\nNote: Only useful for drives with associated changer device.\n\nThis method queries the changer to get a list of media labels.\n\nNote: This updates the media online status.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "List known media labels (Changer Inventory)\n\nNote: Only useful for drives with associated changer device.\n\nThis method queries the changer to get a list of media labels.\n\nNote: This updates the media online status.",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "The list of media labels with associated media Uuid (if any).",
                          "items": {
                            "additionalProperties": false,
                            "description": "Label with optional Uuid",
                            "properties": {
                              "label-text": {
                                "description": "Changer label text (or Barcode)",
                                "type": "string"
                              },
                              "uuid": {
                                "description": "Media Uuid.",
                                "optional": 1,
                                "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                                "type": "string"
                              }
                            },
                            "type": "object"
                          },
                          "type": "array"
                        }
                      },
                      "PUT": {
                        "description": "Update inventory\n\nNote: Only useful for drives with associated changer device.\n\nThis method queries the changer to get a list of media labels. It\nthen loads any unknown media into the drive, reads the label, and\nstore the result to the media database.\n\nNote: This updates the media online status.",
                        "method": "PUT",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Update inventory\n\nNote: Only useful for drives with associated changer device.\n\nThis method queries the changer to get a list of media labels. It\nthen loads any unknown media into the drive, reads the label, and\nstore the result to the media database.\n\nNote: This updates the media online status.",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "read-all-labels": {
                              "description": "Load all tapes and try read labels (even if already inventoried)",
                              "optional": 1,
                              "type": "boolean"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/inventory",
                    "text": "inventory"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Label media\n\nWrite a new media label to the media in 'drive'. The media is\nassigned to the specified 'pool', or else to the free media pool.\n\nNote: The media need to be empty (you may want to format it first).",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Label media\n\nWrite a new media label to the media in 'drive'. The media is\nassigned to the specified 'pool', or else to the free media pool.\n\nNote: The media need to be empty (you may want to format it first).",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "label-text": {
                              "description": "Media Label/Barcode.",
                              "maxLength": 32,
                              "minLength": 2,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "pool": {
                              "description": "Media pool name.",
                              "maxLength": 32,
                              "minLength": 2,
                              "optional": 1,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Write"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/label-media",
                    "text": "label-media"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Load media with specified label\n\nIssue a media load request to the associated changer device.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Load media with specified label\n\nIssue a media load request to the associated changer device.",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "label-text": {
                              "description": "Media Label/Barcode.",
                              "maxLength": 32,
                              "minLength": 2,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/load-media",
                    "text": "load-media"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Load media from the specified slot\n\nIssue a media load request to the associated changer device.",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Load media from the specified slot\n\nIssue a media load request to the associated changer device.",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "source-slot": {
                              "description": "Source slot number.",
                              "minimum": 1,
                              "type": "integer"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/load-slot",
                    "text": "load-slot"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Read media label (optionally inventorize media)",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Read media label (optionally inventorize media)",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "inventorize": {
                              "description": "Inventorize media",
                              "optional": 1,
                              "type": "boolean"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Media label info",
                          "properties": {
                            "ctime": {
                              "description": "Creation time stamp",
                              "type": "integer"
                            },
                            "encryption-key-fingerprint": {
                              "description": "Encryption key fingerprint",
                              "optional": 1,
                              "type": "string"
                            },
                            "label-text": {
                              "description": "Media label text (or Barcode)",
                              "type": "string"
                            },
                            "media-set-ctime": {
                              "description": "MediaSet Creation time stamp",
                              "optional": 1,
                              "type": "integer"
                            },
                            "media-set-uuid": {
                              "description": "MediaSet Uuid (We use the all-zero Uuid to reseve an empty media for a specific pool).",
                              "optional": 1,
                              "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                              "type": "string"
                            },
                            "pool": {
                              "description": "MediaSet Pool",
                              "optional": 1,
                              "type": "string"
                            },
                            "seq-nr": {
                              "description": "MediaSet media sequence number",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "uuid": {
                              "description": "Media Uuid.",
                              "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                              "type": "string"
                            }
                          },
                          "type": "object"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/read-label",
                    "text": "read-label"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Try to restore a tape encryption key",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Try to restore a tape encryption key",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "password": {
                              "description": "Encryption key password.",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/restore-key",
                    "text": "restore-key"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Rewind tape",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Rewind tape",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/rewind",
                    "text": "rewind"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Get drive/media status",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Get drive/media status",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Drive/Media status for Lto SCSI drives.\n\nMedia related data is optional - only set if there is a medium\nloaded.",
                          "properties": {
                            "alert-flags": {
                              "description": "Tape Alert Flags",
                              "optional": 1,
                              "type": "string"
                            },
                            "block-number": {
                              "description": "Current block number",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "blocksize": {
                              "description": "Block size (0 is variable size)",
                              "maximum": 4294967295,
                              "minimum": 0,
                              "type": "integer"
                            },
                            "buffer-mode": {
                              "description": "Drive buffer mode",
                              "maximum": 255,
                              "minimum": 0,
                              "type": "integer"
                            },
                            "bytes-read": {
                              "description": "Total Bytes Read in Medium Life",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "bytes-written": {
                              "description": "Total Bytes Written in Medium Life",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "compression": {
                              "description": "Compression enabled",
                              "type": "boolean"
                            },
                            "density": {
                              "description": "",
                              "enum": [
                                "Unknown",
                                "LTO1",
                                "LTO2",
                                "LTO3",
                                "LTO4",
                                "LTO5",
                                "LTO6",
                                "LTO7",
                                "LTO7M8",
                                "LTO8"
                              ],
                              "optional": 1,
                              "type": "string"
                            },
                            "file-number": {
                              "description": "Current file number",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "manufactured": {
                              "description": "Medium Manufacture Date (epoch)",
                              "optional": 1,
                              "type": "integer"
                            },
                            "medium-passes": {
                              "description": "Count of the total number of times the medium has passed over\nthe head.",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "medium-wearout": {
                              "description": "Estimated tape wearout factor (assuming max. 16000 end-to-end passes)",
                              "optional": 1,
                              "type": "number"
                            },
                            "product": {
                              "description": "Product",
                              "type": "string"
                            },
                            "revision": {
                              "description": "Revision",
                              "type": "string"
                            },
                            "vendor": {
                              "description": "Vendor",
                              "type": "string"
                            },
                            "volume-mounts": {
                              "description": "Number of mounts for the current volume (i.e., Thread Count)",
                              "minimum": 0,
                              "optional": 1,
                              "type": "integer"
                            },
                            "write-protect": {
                              "description": "Media is write protected",
                              "optional": 1,
                              "type": "boolean"
                            }
                          },
                          "type": "object"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/status",
                    "text": "status"
                  },
                  {
                    "info": {
                      "POST": {
                        "description": "Unload media via changer",
                        "method": "POST",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Unload media via changer",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            },
                            "target-slot": {
                              "description": "Target slot number. If omitted, defaults to the slot that the drive was loaded from.",
                              "minimum": 1,
                              "optional": 1,
                              "type": "integer"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Read"
                            ]
                          }
                        },
                        "returns": {
                          "description": "Unique Process/Task ID.",
                          "maxLength": 256,
                          "type": "string"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/unload",
                    "text": "unload"
                  },
                  {
                    "info": {
                      "GET": {
                        "description": "Read Volume Statistics (SCSI log page 17h)",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": false,
                          "description": "Read Volume Statistics (SCSI log page 17h)",
                          "properties": {
                            "drive": {
                              "description": "Drive Identifier.",
                              "maxLength": 32,
                              "minLength": 3,
                              "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                              "type": "string"
                            }
                          }
                        },
                        "permissions": {
                          "check": {
                            "partial": false,
                            "path": [
                              "tape",
                              "device",
                              "{drive}"
                            ],
                            "privs": [
                              "Tape.Audit"
                            ]
                          }
                        },
                        "returns": {
                          "additionalProperties": false,
                          "description": "Volume statistics from SCSI log page 17h",
                          "properties": {
                            "beginning-of-medium-passes": {
                              "description": "Beginning of medium passes",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-load-read-compression-ratio": {
                              "description": "Last load read compression ratio",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-load-write-compression-ratio": {
                              "description": "Last load write compression ratio",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-mount-bytes-read": {
                              "description": "Last mount bytes read",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-mount-bytes-written": {
                              "description": "Last mount bytes written",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-mount-unrecovered-read-errors": {
                              "description": "Last mount unrecovered read errors",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "last-mount-unrecovered-write-errors": {
                              "description": "Last mount unrecovered write errors",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "lifetime-bytes-read": {
                              "description": "Lifetime bytes read",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "lifetime-bytes-written": {
                              "description": "Lifetime bytes written",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "medium-mount-time": {
                              "description": "Medium mount time",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "medium-ready-time": {
                              "description": "Medium ready time",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "middle-of-tape-passes": {
                              "description": "Middle of medium passes",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "serial": {
                              "description": "Volume serial number",
                              "type": "string"
                            },
                            "total-native-capacity": {
                              "description": "Total native capacity",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "total-used-native-capacity": {
                              "description": "Total used native capacity",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-datasets-read": {
                              "description": "Total datasets read",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-datasets-written": {
                              "description": "Total data sets written",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-mounts": {
                              "description": "Volume mounts (thread count)",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-recovered-read-errors": {
                              "description": "Total read retries",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-recovered-write-data-errors": {
                              "description": "Write retries",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-unrecovered-read-errors": {
                              "description": "Total unrecovered read errors",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-unrecovered-write-data-errors": {
                              "description": "Total unrecovered write errors",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-unrecovered-write-servo-errors": {
                              "description": "Total fatal suspended writes",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "volume-write-servo-errors": {
                              "description": "Total suspended writes",
                              "minimum": 0,
                              "type": "integer"
                            },
                            "worm": {
                              "description": "Volume is WORM",
                              "type": "boolean"
                            },
                            "write-protect": {
                              "description": "Write protect",
                              "type": "boolean"
                            }
                          },
                          "type": "object"
                        }
                      }
                    },
                    "leaf": 1,
                    "path": "/tape/drive/{drive}/volume-statistics",
                    "text": "volume-statistics"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "Directory index.",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "Directory index.",
                      "properties": {}
                    },
                    "permissions": {
                      "user": "all"
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 0,
                "path": "/tape/drive/{drive}",
                "text": "{drive}"
              }
            ],
            "info": {
              "GET": {
                "description": "List drives",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "List drives",
                  "properties": {
                    "changer": {
                      "description": "Tape Changer Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    }
                  }
                },
                "permissions": {
                  "description": "List configured tape drives filtered by Tape.Audit privileges",
                  "user": "all"
                },
                "returns": {
                  "description": "The list of configured drives with model information.",
                  "items": {
                    "additionalProperties": true,
                    "description": "Drive list entry",
                    "properties": {
                      "changer": {
                        "description": "Tape Changer Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "optional": 1,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "changer-drivenum": {
                        "default": 0,
                        "description": "Associated changer drive number (requires option changer)",
                        "maximum": 8,
                        "minimum": 0,
                        "optional": 1,
                        "type": "integer"
                      },
                      "model": {
                        "description": "Model (autodetected)",
                        "optional": 1,
                        "type": "string"
                      },
                      "name": {
                        "description": "Drive Identifier.",
                        "maxLength": 32,
                        "minLength": 3,
                        "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                        "type": "string"
                      },
                      "path": {
                        "description": "The path to a LTO SCSI-generic tape device (i.e. '/dev/sg0')",
                        "type": "string"
                      },
                      "serial": {
                        "description": "Serial number (autodetected)",
                        "optional": 1,
                        "type": "string"
                      },
                      "state": {
                        "description": "the state of the drive if locked",
                        "optional": 1,
                        "type": "string"
                      },
                      "vendor": {
                        "description": "Vendor (autodetected)",
                        "optional": 1,
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 0,
            "path": "/tape/drive",
            "text": "drive"
          },
          {
            "children": [
              {
                "info": {
                  "GET": {
                    "description": "List media content",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": true,
                      "description": "List media content",
                      "properties": {
                        "backup-id": {
                          "description": "Backup ID.",
                          "optional": 1,
                          "pattern": "/^[A-Za-z0-9_][A-Za-z0-9._\\-]*$/",
                          "type": "string"
                        },
                        "backup-type": {
                          "description": "Backup type.",
                          "enum": [
                            "vm",
                            "ct",
                            "host"
                          ],
                          "optional": 1,
                          "type": "string"
                        },
                        "label-text": {
                          "description": "Media Label/Barcode.",
                          "maxLength": 32,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "media": {
                          "description": "Media Uuid.",
                          "optional": 1,
                          "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                          "type": "string"
                        },
                        "media-set": {
                          "description": "MediaSet Uuid (We use the all-zero Uuid to reseve an empty media for a specific pool).",
                          "optional": 1,
                          "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                          "type": "string"
                        },
                        "pool": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "List content filtered by Tape.Audit privilege on pool",
                      "user": "all"
                    },
                    "returns": {
                      "description": "Media content list.",
                      "items": {
                        "additionalProperties": false,
                        "description": "Media content list entry",
                        "properties": {
                          "backup-time": {
                            "description": "Snapshot creation time (epoch)",
                            "type": "integer"
                          },
                          "label-text": {
                            "description": "Media label text (or Barcode)",
                            "type": "string"
                          },
                          "media-set-ctime": {
                            "description": "MediaSet Creation time stamp",
                            "type": "integer"
                          },
                          "media-set-name": {
                            "description": "Media set name",
                            "type": "string"
                          },
                          "media-set-uuid": {
                            "description": "MediaSet Uuid (We use the all-zero Uuid to reseve an empty media for a specific pool).",
                            "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                            "type": "string"
                          },
                          "pool": {
                            "description": "Media Pool",
                            "type": "string"
                          },
                          "seq-nr": {
                            "description": "Media set seq_nr",
                            "minimum": 0,
                            "type": "integer"
                          },
                          "snapshot": {
                            "description": "Backup snapshot",
                            "type": "string"
                          },
                          "store": {
                            "description": "Datastore Name",
                            "type": "string"
                          },
                          "uuid": {
                            "description": "Media Uuid.",
                            "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "type": "array"
                    }
                  }
                },
                "leaf": 1,
                "path": "/tape/media/content",
                "text": "content"
              },
              {
                "info": {
                  "GET": {
                    "description": "Destroy media (completely remove from database)",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Destroy media (completely remove from database)",
                      "properties": {
                        "force": {
                          "description": "Force removal (even if media is used in a media set).",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "label-text": {
                          "description": "Media Label/Barcode.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/tape/media/destroy",
                "text": "destroy"
              },
              {
                "children": [
                  {
                    "children": [
                      {
                        "info": {
                          "GET": {
                            "description": "Get current media status",
                            "method": "GET",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Get current media status",
                              "properties": {
                                "uuid": {
                                  "description": "Media Uuid.",
                                  "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                                  "type": "string"
                                }
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          },
                          "POST": {
                            "description": "Update media status (None, 'full', 'damaged' or 'retired')\n\nIt is not allowed to set status to 'writable' or 'unknown' (those\nare internally managed states).",
                            "method": "POST",
                            "parameters": {
                              "additionalProperties": false,
                              "description": "Update media status (None, 'full', 'damaged' or 'retired')\n\nIt is not allowed to set status to 'writable' or 'unknown' (those\nare internally managed states).",
                              "properties": {
                                "status": {
                                  "description": "Media status\nMedia Status",
                                  "enum": [
                                    "writable",
                                    "full",
                                    "unknown",
                                    "damaged",
                                    "retired"
                                  ],
                                  "optional": 1,
                                  "type": "string"
                                },
                                "uuid": {
                                  "description": "Media Uuid.",
                                  "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                                  "type": "string"
                                }
                              }
                            },
                            "returns": {
                              "type": "null"
                            }
                          }
                        },
                        "leaf": 1,
                        "path": "/tape/media/list/{uuid}/status",
                        "text": "status"
                      }
                    ],
                    "info": {
                      "GET": {
                        "description": "Directory index.",
                        "method": "GET",
                        "parameters": {
                          "additionalProperties": true,
                          "description": "Directory index.",
                          "properties": {}
                        },
                        "permissions": {
                          "user": "all"
                        },
                        "returns": {
                          "type": "null"
                        }
                      }
                    },
                    "leaf": 0,
                    "path": "/tape/media/list/{uuid}",
                    "text": "{uuid}"
                  }
                ],
                "info": {
                  "GET": {
                    "description": "List pool media",
                    "method": "GET",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "List pool media",
                      "properties": {
                        "pool": {
                          "description": "Media pool name.",
                          "maxLength": 32,
                          "minLength": 2,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "update-status": {
                          "default": true,
                          "description": "Try to update tape library status (check what tapes are online).",
                          "optional": 1,
                          "type": "boolean"
                        },
                        "update-status-changer": {
                          "description": "Tape Changer Identifier.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "permissions": {
                      "description": "List of registered backup media filtered by Tape.Audit privileges on pool",
                      "user": "all"
                    },
                    "returns": {
                      "description": "List of registered backup media.",
                      "items": {
                        "additionalProperties": false,
                        "description": "Media list entry",
                        "properties": {
                          "catalog": {
                            "description": "Catalog status OK",
                            "type": "boolean"
                          },
                          "ctime": {
                            "description": "Creation time stamp",
                            "type": "integer"
                          },
                          "expired": {
                            "description": "Expired flag",
                            "type": "boolean"
                          },
                          "label-text": {
                            "description": "Media label text (or Barcode)",
                            "type": "string"
                          },
                          "location": {
                            "description": "Media location (e.g. 'offline', 'online-<changer_name>', 'vault-<vault_name>')",
                            "type": "string"
                          },
                          "media-set-ctime": {
                            "description": "MediaSet creation time stamp",
                            "optional": 1,
                            "type": "integer"
                          },
                          "media-set-name": {
                            "description": "Media set name",
                            "optional": 1,
                            "type": "string"
                          },
                          "media-set-uuid": {
                            "description": "MediaSet Uuid (We use the all-zero Uuid to reseve an empty media for a specific pool).",
                            "optional": 1,
                            "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                            "type": "string"
                          },
                          "pool": {
                            "description": "Media Pool",
                            "optional": 1,
                            "type": "string"
                          },
                          "seq-nr": {
                            "description": "Media set seq_nr",
                            "minimum": 0,
                            "optional": 1,
                            "type": "integer"
                          },
                          "status": {
                            "description": "Media status\nMedia Status",
                            "enum": [
                              "writable",
                              "full",
                              "unknown",
                              "damaged",
                              "retired"
                            ],
                            "type": "string"
                          },
                          "uuid": {
                            "description": "Media Uuid.",
                            "pattern": "/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/",
                            "type": "string"
                          }
                        },
                        "type": "object"
                      },
                      "type": "array"
                    }
                  }
                },
                "leaf": 0,
                "path": "/tape/media/list",
                "text": "list"
              },
              {
                "info": {
                  "POST": {
                    "description": "Change Tape location to vault (if given), or offline.",
                    "method": "POST",
                    "parameters": {
                      "additionalProperties": false,
                      "description": "Change Tape location to vault (if given), or offline.",
                      "properties": {
                        "label-text": {
                          "description": "Media Label/Barcode.",
                          "maxLength": 32,
                          "minLength": 2,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        },
                        "vault-name": {
                          "description": "Vault name.",
                          "maxLength": 32,
                          "minLength": 3,
                          "optional": 1,
                          "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                          "type": "string"
                        }
                      }
                    },
                    "returns": {
                      "type": "null"
                    }
                  }
                },
                "leaf": 1,
                "path": "/tape/media/move",
                "text": "move"
              }
            ],
            "info": {
              "GET": {
                "description": "Directory index.",
                "method": "GET",
                "parameters": {
                  "additionalProperties": true,
                  "description": "Directory index.",
                  "properties": {}
                },
                "permissions": {
                  "user": "all"
                },
                "returns": {
                  "type": "null"
                }
              }
            },
            "leaf": 0,
            "path": "/tape/media",
            "text": "media"
          },
          {
            "info": {
              "POST": {
                "description": "Restore data from media-set",
                "method": "POST",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Restore data from media-set",
                  "properties": {
                    "drive": {
                      "description": "Drive Identifier.",
                      "maxLength": 32,
                      "minLength": 3,
                      "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "media-set": {
                      "description": "Media set UUID.",
                      "type": "string"
                    },
                    "notify-user": {
                      "description": "User ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                      "type": "string"
                    },
                    "owner": {
                      "description": "Authentication ID",
                      "maxLength": 64,
                      "minLength": 3,
                      "optional": 1,
                      "pattern": "/^(?:(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)|(?:[^\\s:/[:cntrl:]]+)@(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)!(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*))$/",
                      "type": "string"
                    },
                    "store": {
                      "description": "A list of Datastore mappings (or single datastore), comma separated. For example 'a=b,e' maps the source datastore 'a' to target 'b and all other sources to the default 'e'. If no default is given, only the specified sources are mapped.",
                      "format": {
                        "description": "Datastore mapping list.",
                        "items": {
                          "description": "Datastore mapping.",
                          "maxLength": 65,
                          "minLength": 3,
                          "pattern": "/(:?(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)=)?(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)/",
                          "type": "string",
                          "typetext": "(<source>=)?<target>"
                        },
                        "type": "array"
                      },
                      "type": "string",
                      "typetext": "[(<source>=)?<target>, ...]"
                    }
                  }
                },
                "permissions": {
                  "description": "The user needs Tape.Read privilege on /tape/pool/{pool} and /tape/drive/{drive}, Datastore.Backup privilege on /datastore/{store}.",
                  "user": "all"
                },
                "returns": {
                  "description": "Unique Process/Task ID.",
                  "maxLength": 256,
                  "type": "string"
                }
              }
            },
            "leaf": 1,
            "path": "/tape/restore",
            "text": "restore"
          },
          {
            "info": {
              "GET": {
                "description": "Scan for SCSI tape changers",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Scan for SCSI tape changers",
                  "properties": {}
                },
                "returns": {
                  "description": "The list of autodetected tape changers.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Tape device information",
                    "properties": {
                      "kind": {
                        "description": "Kind of device",
                        "enum": [
                          "changer",
                          "tape"
                        ],
                        "type": "string"
                      },
                      "major": {
                        "description": "Device major number",
                        "maximum": 4294967295,
                        "minimum": 0,
                        "type": "integer"
                      },
                      "minor": {
                        "description": "Device minor number",
                        "maximum": 4294967295,
                        "minimum": 0,
                        "type": "integer"
                      },
                      "model": {
                        "description": "Model (autodetected)",
                        "type": "string"
                      },
                      "path": {
                        "description": "Path to the linux device node",
                        "type": "string"
                      },
                      "serial": {
                        "description": "Serial number (autodetected)",
                        "type": "string"
                      },
                      "vendor": {
                        "description": "Vendor (autodetected)",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 1,
            "path": "/tape/scan-changers",
            "text": "scan-changers"
          },
          {
            "info": {
              "GET": {
                "description": "Scan tape drives",
                "method": "GET",
                "parameters": {
                  "additionalProperties": false,
                  "description": "Scan tape drives",
                  "properties": {}
                },
                "returns": {
                  "description": "The list of autodetected tape drives.",
                  "items": {
                    "additionalProperties": false,
                    "description": "Tape device information",
                    "properties": {
                      "kind": {
                        "description": "Kind of device",
                        "enum": [
                          "changer",
                          "tape"
                        ],
                        "type": "string"
                      },
                      "major": {
                        "description": "Device major number",
                        "maximum": 4294967295,
                        "minimum": 0,
                        "type": "integer"
                      },
                      "minor": {
                        "description": "Device minor number",
                        "maximum": 4294967295,
                        "minimum": 0,
                        "type": "integer"
                      },
                      "model": {
                        "description": "Model (autodetected)",
                        "type": "string"
                      },
                      "path": {
                        "description": "Path to the linux device node",
                        "type": "string"
                      },
                      "serial": {
                        "description": "Serial number (autodetected)",
                        "type": "string"
                      },
                      "vendor": {
                        "description": "Vendor (autodetected)",
                        "type": "string"
                      }
                    },
                    "type": "object"
                  },
                  "type": "array"
                }
              }
            },
            "leaf": 1,
            "path": "/tape/scan-drives",
            "text": "scan-drives"
          }
        ],
        "info": {
          "GET": {
            "description": "Directory index.",
            "method": "GET",
            "parameters": {
              "additionalProperties": true,
              "description": "Directory index.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 0,
        "path": "/tape",
        "text": "tape"
      },
      {
        "info": {
          "GET": {
            "description": "Proxmox Backup Server API version.",
            "method": "GET",
            "parameters": {
              "additionalProperties": false,
              "description": "Proxmox Backup Server API version.",
              "properties": {}
            },
            "permissions": {
              "user": "all"
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/version",
        "text": "version"
      }
    ],
    "expanded": true,
    "info": {
      "GET": {
        "description": "Directory index.",
        "method": "GET",
        "parameters": {
          "additionalProperties": true,
          "description": "Directory index.",
          "properties": {}
        },
        "permissions": {
          "user": "all"
        },
        "returns": {
          "type": "null"
        }
      }
    },
    "leaf": 0,
    "path": "/",
    "text": "&#x200b;Management API (HTTP)"
  },
  {
    "children": [
      {
        "info": {
          "POST": {
            "description": "Upload binary blob file.",
            "method": "UPLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Upload binary blob file.",
              "properties": {
                "encoded-size": {
                  "description": "Encoded blob size.",
                  "maximum": 16777260,
                  "minimum": 12,
                  "type": "integer"
                },
                "file-name": {
                  "description": "Backup archive name.",
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/blob",
        "text": "blob"
      },
      {
        "info": {
          "POST": {
            "description": "Upload a new chunk.",
            "method": "UPLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Upload a new chunk.",
              "properties": {
                "digest": {
                  "description": "Chunk digest (SHA256).",
                  "pattern": "/^[a-f0-9]{64}$/",
                  "type": "string"
                },
                "encoded-size": {
                  "description": "Encoded chunk size.",
                  "maximum": 16777260,
                  "minimum": 13,
                  "type": "integer"
                },
                "size": {
                  "description": "Chunk size.",
                  "maximum": 16777216,
                  "minimum": 1,
                  "type": "integer"
                },
                "wid": {
                  "description": "Dynamic writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/dynamic_chunk",
        "text": "dynamic_chunk"
      },
      {
        "info": {
          "POST": {
            "description": "Close dynamic index writer.",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Close dynamic index writer.",
              "properties": {
                "chunk-count": {
                  "description": "Chunk count. This is used to verify that the server got all chunks.",
                  "minimum": 1,
                  "type": "integer"
                },
                "csum": {
                  "description": "Digest list checksum.",
                  "type": "string"
                },
                "size": {
                  "description": "File size. This is used to verify that the server got all data.",
                  "minimum": 1,
                  "type": "integer"
                },
                "wid": {
                  "description": "Dynamic writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/dynamic_close",
        "text": "dynamic_close"
      },
      {
        "info": {
          "POST": {
            "description": "Create dynamic chunk index file.",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Create dynamic chunk index file.",
              "properties": {
                "archive-name": {
                  "description": "Backup archive name.",
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          },
          "PUT": {
            "description": "Append chunk to dynamic index writer.",
            "method": "PUT",
            "parameters": {
              "additionalProperties": false,
              "description": "Append chunk to dynamic index writer.",
              "properties": {
                "digest-list": {
                  "description": "Chunk digest list.",
                  "items": {
                    "description": "Chunk digest (SHA256).",
                    "pattern": "/^[a-f0-9]{64}$/",
                    "type": "string"
                  },
                  "type": "array"
                },
                "offset-list": {
                  "description": "Chunk offset list.",
                  "items": {
                    "description": "Corresponding chunk offsets.",
                    "minimum": 0,
                    "type": "integer"
                  },
                  "type": "array"
                },
                "wid": {
                  "description": "Dynamic writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/dynamic_index",
        "text": "dynamic_index"
      },
      {
        "info": {
          "POST": {
            "description": "Mark backup as finished.",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Mark backup as finished.",
              "properties": {}
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/finish",
        "text": "finish"
      },
      {
        "info": {
          "POST": {
            "description": "Upload a new chunk.",
            "method": "UPLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Upload a new chunk.",
              "properties": {
                "digest": {
                  "description": "Chunk digest (SHA256).",
                  "pattern": "/^[a-f0-9]{64}$/",
                  "type": "string"
                },
                "encoded-size": {
                  "description": "Encoded chunk size.",
                  "maximum": 16777260,
                  "minimum": 13,
                  "type": "integer"
                },
                "size": {
                  "description": "Chunk size.",
                  "maximum": 16777216,
                  "minimum": 1,
                  "type": "integer"
                },
                "wid": {
                  "description": "Fixed writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/fixed_chunk",
        "text": "fixed_chunk"
      },
      {
        "info": {
          "POST": {
            "description": "Close fixed index writer.",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Close fixed index writer.",
              "properties": {
                "chunk-count": {
                  "description": "Chunk count. This is used to verify that the server got all chunks. Ignored for incremental backups.",
                  "minimum": 0,
                  "type": "integer"
                },
                "csum": {
                  "description": "Digest list checksum.",
                  "type": "string"
                },
                "size": {
                  "description": "File size. This is used to verify that the server got all data. Ignored for incremental backups.",
                  "minimum": 0,
                  "type": "integer"
                },
                "wid": {
                  "description": "Fixed writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/fixed_close",
        "text": "fixed_close"
      },
      {
        "info": {
          "POST": {
            "description": "Create fixed chunk index file.",
            "method": "POST",
            "parameters": {
              "additionalProperties": false,
              "description": "Create fixed chunk index file.",
              "properties": {
                "archive-name": {
                  "description": "Backup archive name.",
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                },
                "reuse-csum": {
                  "description": "If set, compare last backup's csum and reuse index for incremental backup if it matches.",
                  "optional": 1,
                  "type": "string"
                },
                "size": {
                  "description": "File size.",
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          },
          "PUT": {
            "description": "Append chunk to fixed index writer.",
            "method": "PUT",
            "parameters": {
              "additionalProperties": false,
              "description": "Append chunk to fixed index writer.",
              "properties": {
                "digest-list": {
                  "description": "Chunk digest list.",
                  "items": {
                    "description": "Chunk digest (SHA256).",
                    "pattern": "/^[a-f0-9]{64}$/",
                    "type": "string"
                  },
                  "type": "array"
                },
                "offset-list": {
                  "description": "Chunk offset list.",
                  "items": {
                    "description": "Corresponding chunk offsets.",
                    "minimum": 0,
                    "type": "integer"
                  },
                  "type": "array"
                },
                "wid": {
                  "description": "Fixed writer ID.",
                  "maximum": 256,
                  "minimum": 1,
                  "type": "integer"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/fixed_index",
        "text": "fixed_index"
      },
      {
        "info": {
          "GET": {
            "description": "Download archive from previous backup.",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Download archive from previous backup.",
              "properties": {
                "archive-name": {
                  "description": "Backup archive name.",
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/previous",
        "text": "previous"
      },
      {
        "info": {
          "GET": {
            "description": "Get previous backup time.",
            "method": "GET",
            "parameters": {
              "additionalProperties": false,
              "description": "Get previous backup time.",
              "properties": {}
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/previous_backup_time",
        "text": "previous_backup_time"
      },
      {
        "info": {
          "POST": {
            "description": "Test upload speed.",
            "method": "UPLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Test upload speed.",
              "properties": {}
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/backup/_upgrade_/speedtest",
        "text": "speedtest"
      }
    ],
    "info": {
      "GET": {
        "description": "Directory index.",
        "method": "GET",
        "parameters": {
          "additionalProperties": true,
          "description": "Directory index.",
          "properties": {}
        },
        "permissions": {
          "user": "all"
        },
        "returns": {
          "type": "null"
        }
      }
    },
    "leaf": 0,
    "path": "/backup/_upgrade_",
    "text": "Backup API (HTTP/2)"
  },
  {
    "children": [
      {
        "info": {
          "GET": {
            "description": "Download specified chunk.",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Download specified chunk.",
              "properties": {
                "digest": {
                  "description": "Chunk digest (SHA256).",
                  "pattern": "/^[a-f0-9]{64}$/",
                  "type": "string"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/reader/_upgrade_/chunk",
        "text": "chunk"
      },
      {
        "info": {
          "GET": {
            "description": "Download specified file.",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Download specified file.",
              "properties": {
                "file-name": {
                  "description": "Backup archive name.",
                  "pattern": "/^(?:[A-Za-z0-9_][A-Za-z0-9._\\-]*)$/",
                  "type": "string"
                }
              }
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/reader/_upgrade_/download",
        "text": "download"
      },
      {
        "info": {
          "GET": {
            "description": "Test 1M block download speed.",
            "method": "DOWNLOAD",
            "parameters": {
              "additionalProperties": false,
              "description": "Test 1M block download speed.",
              "properties": {}
            },
            "returns": {
              "type": "null"
            }
          }
        },
        "leaf": 1,
        "path": "/reader/_upgrade_/speedtest",
        "text": "speedtest"
      }
    ],
    "info": {
      "GET": {
        "description": "Directory index.",
        "method": "GET",
        "parameters": {
          "additionalProperties": true,
          "description": "Directory index.",
          "properties": {}
        },
        "permissions": {
          "user": "all"
        },
        "returns": {
          "type": "null"
        }
      }
    },
    "leaf": 0,
    "path": "/reader/_upgrade_",
    "text": "Restore API (HTTP/2)"
  }
];
// avoid errors when running without development tools
if (!Ext.isDefined(Ext.global.console)) {
    var console = {
        dir: function() {},
        log: function() {}
    };
}

Ext.onReady(function() {

    Ext.define('pve-param-schema', {
        extend: 'Ext.data.Model',
        fields:  [
	    'name', 'type', 'typetext', 'description', 'verbose_description',
	    'enum', 'minimum', 'maximum', 'minLength', 'maxLength',
	    'pattern', 'title', 'requires', 'format', 'default',
	    'disallow', 'extends', 'links',
	    {
		name: 'optional',
		type: 'boolean'
	    }
	]
    });

    var store = Ext.define('pve-updated-treestore', {
	extend: 'Ext.data.TreeStore',
	model: Ext.define('pve-api-doc', {
            extend: 'Ext.data.Model',
            fields:  [
		'path', 'info', 'text',
	    ]
	}),
        proxy: {
            type: 'memory',
            data: pbsapi
        },
        sorters: [{
            property: 'leaf',
            direction: 'ASC'
        }, {
            property: 'text',
            direction: 'ASC'
	}],
	filterer: 'bottomup',
	doFilter: function(node) {
	    this.filterNodes(node, this.getFilters().getFilterFn(), true);
	},

	filterNodes: function(node, filterFn, parentVisible) {
	    var me = this,
		bottomUpFiltering = me.filterer === 'bottomup',
		match = filterFn(node) && parentVisible || (node.isRoot() && !me.getRootVisible()),
		childNodes = node.childNodes,
		len = childNodes && childNodes.length, i, matchingChildren;

	    if (len) {
		for (i = 0; i < len; ++i) {
		    matchingChildren = me.filterNodes(childNodes[i], filterFn, match || bottomUpFiltering) || matchingChildren;
		}
		if (bottomUpFiltering) {
		    match = matchingChildren || match;
		}
	    }

	    node.set("visible", match, me._silentOptions);
	    return match;
	},

    }).create();

    var render_description = function(value, metaData, record) {
	var pdef = record.data;

	value = pdef.verbose_description || value;

	// TODO: try to render asciidoc correctly

	metaData.style = 'white-space:pre-wrap;'

	return Ext.htmlEncode(value);
    };

    var render_type = function(value, metaData, record) {
	var pdef = record.data;

	return pdef['enum'] ? 'enum' : (pdef.type || 'string');
    };

    var render_format = function(value, metaData, record) {
	var pdef = record.data;

	metaData.style = 'white-space:normal;'

	if (pdef.typetext)
	    return Ext.htmlEncode(pdef.typetext);

	if (pdef['enum'])
	    return pdef['enum'].join(' | ');

	if (pdef.format)
	    return pdef.format;

	if (pdef.pattern)
	    return Ext.htmlEncode(pdef.pattern);

	return '';
    };

    var real_path = function(path) {
	return path.replace(/^.*\/_upgrade_(\/)?/, "/");
    };

    var permission_text = function(permission) {
	let permhtml = "";

	if (permission.user) {
	    if (!permission.description) {
		if (permission.user === 'world') {
		    permhtml += "Accessible without any authentication.";
		} else if (permission.user === 'all') {
		    permhtml += "Accessible by all authenticated users.";
		} else {
		    permhtml += 'Onyl accessible by user "' +
			permission.user + '"';
		}
	    }
	} else if (permission.check) {
	    permhtml += "<pre>Check: " +
		Ext.htmlEncode(Ext.JSON.encode(permission.check))  + "</pre>";
	} else if (permission.userParam) {
	    permhtml += `<div>Check if user matches parameter '${permission.userParam}'`;
	} else if (permission.or) {
	    permhtml += "<div>Or<div style='padding-left: 10px;'>";
	    Ext.Array.each(permission.or, function(sub_permission) {
		permhtml += permission_text(sub_permission);
	    })
	    permhtml += "</div></div>";
	} else if (permission.and) {
	    permhtml += "<div>And<div style='padding-left: 10px;'>";
	    Ext.Array.each(permission.and, function(sub_permission) {
		permhtml += permission_text(sub_permission);
	    })
	    permhtml += "</div></div>";
	} else {
	    //console.log(permission);
	    permhtml += "Unknown syntax!";
	}

	return permhtml;
    };

    var render_docu = function(data) {
	var md = data.info;

	// console.dir(data);

	var items = [];

	var clicmdhash = {
	    GET: 'get',
	    POST: 'create',
	    PUT: 'set',
	    DELETE: 'delete'
	};

	Ext.Array.each(['GET', 'POST', 'PUT', 'DELETE'], function(method) {
	    var info = md[method];
	    if (info) {

		var usage = "";

		usage += "<table><tr><td>HTTP:&nbsp;&nbsp;&nbsp;</td><td>"
		    + method + " " + real_path("/api2/json" + data.path) + "</td></tr>";

		var sections = [
		    {
			title: 'Description',
			html: Ext.htmlEncode(info.description),
			bodyPadding: 10
		    },
		    {
			title: 'Usage',
			html: usage,
			bodyPadding: 10
		    }
		];

		if (info.parameters && info.parameters.properties) {

		    var pstore = Ext.create('Ext.data.Store', {
			model: 'pve-param-schema',
			proxy: {
			    type: 'memory'
			},
			groupField: 'optional',
			sorters: [
			    {
				property: 'name',
				direction: 'ASC'
			    }
			]
		    });

		    Ext.Object.each(info.parameters.properties, function(name, pdef) {
			pdef.name = name;
			pstore.add(pdef);
		    });

		    pstore.sort();

		    var groupingFeature = Ext.create('Ext.grid.feature.Grouping',{
			enableGroupingMenu: false,
			groupHeaderTpl: '<tpl if="groupValue">Optional</tpl><tpl if="!groupValue">Required</tpl>'
		    });

		    sections.push({
			xtype: 'gridpanel',
			title: 'Parameters',
			features: [groupingFeature],
			store: pstore,
			viewConfig: {
			    trackOver: false,
			    stripeRows: true
			},
			columns: [
			    {
				header: 'Name',
				dataIndex: 'name',
				flex: 1
			    },
			    {
				header: 'Type',
				dataIndex: 'type',
				renderer: render_type,
				flex: 1
			    },
			    {
				header: 'Default',
				dataIndex: 'default',
				flex: 1
			    },
			    {
				header: 'Format',
				dataIndex: 'type',
				renderer: render_format,
				flex: 2
			    },
			    {
				header: 'Description',
				dataIndex: 'description',
				renderer: render_description,
				flex: 6
			    }
			]
		    });

		}

		if (info.returns) {

		    var retinf = info.returns;
		    var rtype = retinf.type;
		    if (!rtype && retinf.items)
			rtype = 'array';
		    if (!rtype)
			rtype = 'object';

		    var rpstore = Ext.create('Ext.data.Store', {
			model: 'pve-param-schema',
			proxy: {
			    type: 'memory'
			},
			groupField: 'optional',
			sorters: [
			    {
				property: 'name',
				direction: 'ASC'
			   }
			]
		    });

		    var properties;
		    if (rtype === 'array' && retinf.items.properties) {
			properties = retinf.items.properties;
		    }

		    if (rtype === 'object' && retinf.properties) {
			properties = retinf.properties;
		    }

		    Ext.Object.each(properties, function(name, pdef) {
			pdef.name = name;
			rpstore.add(pdef);
		    });

		    rpstore.sort();

		    var groupingFeature = Ext.create('Ext.grid.feature.Grouping',{
			enableGroupingMenu: false,
			groupHeaderTpl: '<tpl if="groupValue">Optional</tpl><tpl if="!groupValue">Obligatory</tpl>'
		    });
		    var returnhtml;
		    if (retinf.items) {
			returnhtml = '<pre>items: ' + Ext.htmlEncode(JSON.stringify(retinf.items, null, 4)) + '</pre>';
		    }

		    if (retinf.properties) {
			returnhtml = returnhtml || '';
			returnhtml += '<pre>properties:' + Ext.htmlEncode(JSON.stringify(retinf.properties, null, 4)) + '</pre>';
		    }

		    var rawSection = Ext.create('Ext.panel.Panel', {
			bodyPadding: '0px 10px 10px 10px',
			html: returnhtml,
			hidden: true
		    });

		    sections.push({
			xtype: 'gridpanel',
			title: 'Returns: ' + rtype,
			features: [groupingFeature],
			store: rpstore,
			viewConfig: {
			    trackOver: false,
			    stripeRows: true
			},
		    columns: [
			{
			    header: 'Name',
			    dataIndex: 'name',
			    flex: 1
			},
			{
			    header: 'Type',
			    dataIndex: 'type',
			    renderer: render_type,
			    flex: 1
			},
			{
			    header: 'Default',
			    dataIndex: 'default',
			    flex: 1
			},
			{
			    header: 'Format',
			    dataIndex: 'type',
			    renderer: render_format,
			    flex: 2
			},
			{
			    header: 'Description',
			    dataIndex: 'description',
			    renderer: render_description,
			    flex: 6
			}
		    ],
		    bbar: [
			{
			    xtype: 'button',
			    text: 'Show RAW',
			    handler: function(btn) {
				rawSection.setVisible(!rawSection.isVisible());
				btn.setText(rawSection.isVisible() ? 'Hide RAW' : 'Show RAW');
			    }}
		    ]
		});

		sections.push(rawSection);


		}

		if (!data.path.match(/\/_upgrade_/)) {
		    var permhtml = '';

		    if (!info.permissions) {
			permhtml = "Root only.";
		    } else {
			if (info.permissions.description) {
			    permhtml += "<div style='white-space:pre-wrap;padding-bottom:10px;'>" +
				Ext.htmlEncode(info.permissions.description) + "</div>";
			}
			permhtml += permission_text(info.permissions);
		    }

		    // we do not have this information for PBS api
		    //if (!info.allowtoken) {
		    //    permhtml += "<br />This API endpoint is not available for API tokens."
		    //}

		    sections.push({
			title: 'Required permissions',
			bodyPadding: 10,
			html: permhtml
		    });
		}

		items.push({
		    title: method,
		    autoScroll: true,
		    defaults: {
			border: false
		    },
		    items: sections
		});
	    }
	});

	var ct = Ext.getCmp('docview');
	ct.setTitle("Path: " +  real_path(data.path));
	ct.removeAll(true);
	ct.add(items);
	ct.setActiveTab(0);
    };

    Ext.define('Ext.form.SearchField', {
	extend: 'Ext.form.field.Text',
	alias: 'widget.searchfield',

	emptyText: 'Search...',

	flex: 1,

	inputType: 'search',
	listeners: {
	    'change': function(){

		var value = this.getValue();
		if (!Ext.isEmpty(value)) {
		    store.filter({
			property: 'path',
			value: value,
			anyMatch: true
		    });
		} else {
		    store.clearFilter();
		}
	    }
	}
    });

    var tree = Ext.create('Ext.tree.Panel', {
	title: 'Resource Tree',
	tbar: [
	    {
		xtype: 'searchfield',
	    }
	],
	tools: [
	    {
		type: 'expand',
		tooltip: 'Expand all',
		tooltipType: 'title',
		callback: (tree) => tree.expandAll(),
	    },
	    {
		type: 'collapse',
		tooltip: 'Collapse all',
		tooltipType: 'title',
		callback: (tree) => tree.collapseAll(),
	    },
	],
        store: store,
	width: 200,
        region: 'west',
        split: true,
        margins: '5 0 5 5',
        rootVisible: false,
	listeners: {
	    selectionchange: function(v, selections) {
		if (!selections[0])
		    return;
		var rec = selections[0];
		render_docu(rec.data);
		location.hash = '#' + rec.data.path;
	    }
	}
    });

    Ext.create('Ext.container.Viewport', {
	layout: 'border',
	renderTo: Ext.getBody(),
	items: [
	    tree,
	    {
		xtype: 'tabpanel',
		title: 'Documentation',
		id: 'docview',
		region: 'center',
		margins: '5 5 5 0',
		layout: 'fit',
		items: []
	    }
	]
    });

    var deepLink = function() {
	var path = window.location.hash.substring(1).replace(/\/\s*$/, '')
	var endpoint = store.findNode('path', path);

	if (endpoint) {
	    tree.getSelectionModel().select(endpoint);
	    tree.expandPath(endpoint.getPath());
	    render_docu(endpoint.data);
	}
    }
    window.onhashchange = deepLink;

    deepLink();

});
