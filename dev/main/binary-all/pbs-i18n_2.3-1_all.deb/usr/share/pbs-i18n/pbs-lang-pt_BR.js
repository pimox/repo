// -
// Proxmox Message Catalog: pbs-lang-pt_BR.js
__proxmox_i18n_msgcat__ = {"1010534570":["Online"],"1030802605":["Gestão usuários"],"1042057489":["Domínio"],"1095677363":["Sumário"],"1097310050":["Conteúdo"],"1120365745":["Editar"],"112472755":["Usuários"],"113230335":["Backup"],"1155649139":["Tem certeza que deseja remover a entrada {0}"],"117505411":["Permissões"],"1179034313":["Procurar"],"1211135397":["Atualizações"],"125463051":["Logout"],"1266644741":["Parar"],"1277169241":["desconhecido"],"1288449246":["Enviar chave de assinatura"],"129717419":["Este não é um nome de DNS válido"],"1308245100":["Tempo de Início"],"1312749210":["Uso de CPU"],"1313942339":["Erro desconhecido"],"135637716":["Atualizar"],"1363671402":["Valor"],"1364578413":["Tipo"],"1397651250":["Modo"],"1428881496":["Administração do Servidor"],"1432485131":["Geral"],"1441655762":["Logar"],"1492679118":["Memória"],"1496092135":["Checar"],"1509197333":["Dispositivo de Rede"],"1517138453":["Nome de usuário"],"1524227104":["Confirmar senha"],"1573770551":["Versão"],"1582017048":["Ver"],"1591441098":["Console"],"1608836100":["Horário"],"1613374632":["Nome do arquivo"],"1621507602":["Usuário"],"1642511898":["Não"],"1642576020":["Contagem"],"1672675413":["Serviços"],"1682907645":["dia"],"1692103706":["Fuso Horário"],"1725856265":["Descrição"],"175614239":["Ação"],"1756866391":["Servidor de DNS"],"1768209177":["Download"],"1789283792":["Usado"],"1801905238":["Caminho"],"180669460":["Endereço IP"],"180921696":["Reset"],"180965513":["nunca"],"1827006442":["Falha no login. Por favor, tente novamente."],"182978943":["Iniciar"],"1837256131":["Uso do disco"],"1839360066":["Expira"],"1843267341":["Caracteres permitidos"],"1853244196":["Saída"],"1860367182":["parada"],"1911669355":["Desligar"],"1938660593":["Erro"],"1971275149":["Grupos"],"1974461284":["Todos"],"1989268106":["dias"],"2003021401":["Permissões de Usuário"],"2018011009":["Autenticação"],"2023431579":["Com sucesso"],"2025656483":["Pool"],"2123320219":["Pacote"],"2142306162":["Formato"],"253699798":["Início Automático"],"254903484":["Sistema"],"265887727":["Administração"],"266367750":["Nome"],"267393898":["Notas"],"267943793":["Restaurar"],"271285817":["Regra"],"311628609":["Exemplo"],"330376117":["Uso de memória"],"337799720":["Diretório"],"340849291":["Chave de Assinatura"],"343848780":["em execuçao"],"370850709":["Compressão"],"397479987":["Carregando..."],"400411952":["Domínio"],"407871486":["Comentário"],"40861564":["Envio"],"420340861":["Criar"],"420819256":["Nome"],"433860734":["Padrão"],"434265056":["Sobrenome"],"440640172":["Recarregar"],"442169810":["{0} horas"],"442426457":["Configuração"],"443800475":["Idioma"],"451774105":["Gateway"],"455261812":["Dono"],"478602302":["Ativado"],"499362324":["Adicionar"],"502047894":["Estado"],"529077071":["Ativo"],"544810223":["Assunto"],"557963277":["Privilégios"],"562285039":["Confirmar"],"564498461":["Remover"],"583450315":["Sem alterações"],"599530703":["Hora do Servidor"],"6222351":["Status"],"642223740":["Tamanho"],"711771863":["Término"],"750979128":["Senha"],"755395997":["Total"],"759938308":["Sempre"],"761816144":["Mascará de rede"],"765964251":["nenhum"],"772725124":["Mensagem"],"793046412":["Reiniciar"],"806397589":["Alterações pendentes"],"808120719":["Host"],"828892957":["Contas"],"866399792":["Sim"],"879231789":["Nó"],"888343212":["Propagação"],"893259077":["Opções"],"91525164":["Grupo"],"947972530":["Layout de Teclado"],"949874714":["Ajuda"],"966695021":["Tarefas"],"974743969":["Shell"],"974794979":["Erro de Conexão"],"9862966":["Somente Erros"],"989937162":["Por favor, aguarde..."]};

function fnv31a(text) {
    var len = text.length;
    var hval = 0x811c9dc5;
    for (var i = 0; i < len; i++) {
	var c = text.charCodeAt(i);
	hval ^= c;
	hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    hval &= 0x7fffffff;
    return hval;
}

function gettext(buf) {
    var digest = fnv31a(buf);
    var data = __proxmox_i18n_msgcat__[digest];
    if (!data) {
	return buf;
    }
    return data[0] || buf;
}
